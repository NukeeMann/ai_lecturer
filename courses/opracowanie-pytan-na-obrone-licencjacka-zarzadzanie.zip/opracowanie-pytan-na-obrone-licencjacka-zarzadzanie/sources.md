# Sources: Opracowanie pytań na obronę licencjacką – Zarządzanie

> Working bibliography for course generation. Each entry must conform to
> `SourceSchema` (`src/lib/schemas/lesson.ts`) when copied into a lesson:
>   { url, title, kind: "paper" | "video" | "article" | "book", author?, year? }
> Prefer DOI / arxiv / Wikipedia / official docs / official YouTube channels.
> Avoid medium.com, towardsdatascience.com, dev.to, personal blogs.

## Course-wide references

Klasyczne podręczniki polskiej i światowej szkoły zarządzania – cytowane przez większość lekcji jako źródło pojęć, definicji i przykładów. Można je przywoływać z dowolnej lekcji o zarządzaniu.

- [Podstawy zarządzania organizacjami (PWE / PWN)](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; klasyczny anglosaski podręcznik (wyd. 12), polskie tłumaczenie wykorzystywane na większości polskich uczelni; obejmuje cały zakres pyt. 1–25.
- [Kierowanie](https://ksiegarnia.pwn.pl/Kierowanie,67806624,p.html) — kind: book; author: James A. F. Stoner, R. Edward Freeman, Daniel R. Gilbert; year: 2011; standardowy podręcznik PWE/PWN, klasyk teorii zarządzania.
- [Praktyka zarządzania](https://www.empik.com/praktyka-zarzadzania-drucker-peter-f,prod37068999,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 2005; fundament myśli zarządczej XX w., zarządzanie przez cele (MBO), przedsiębiorczość.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; biblia marketingu; wyd. 15 (i nowsze) zawiera definicje marketingu tradycyjnego i współczesnego, model 4P/5P, cykl życia produktu, plan marketingowy, IMC.
- [Strategia konkurencji. Metody analizy sektorów i konkurentów](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; pięć sił, strategie generyczne (lider kosztowy, dyferencjacja, koncentracja).
- [Zarządzanie zasobami ludzkimi](https://www.empik.com/zarzadzanie-zasobami-ludzkimi-armstrong-michael-taylor-stephen,prod177953830,ksiazka-p) — kind: book; author: Michael Armstrong, Stephen Taylor; year: 2022; podstawowy podręcznik ZZL (cykl życia pracownika, narzędzia, motywowanie).
- [Zarządzanie. Teoria i praktyka](https://www.empik.com/zarzadzanie-teoria-i-praktyka-kozminski-andrzej-k-piotrowski-wlodzimierz,prod14627907,ksiazka-p) — kind: book; author: Andrzej K. Koźmiński, Włodzimierz Piotrowski; year: 2013; standardowy polski podręcznik akademicki obejmujący strategie, struktury, motywowanie, kontrolowanie.
- [Encyclopaedia Britannica — Management](https://www.britannica.com/money/management) — kind: article; year: 2024; encyklopedyczne ujęcie historii i funkcji zarządzania.
- [Wikipedia (PL) — Zarządzanie](https://pl.wikipedia.org/wiki/Zarządzanie) — kind: article; szybkie polskie ujęcie + bibliografia akademicka.

## Jak pracować z kursem przed obroną

- [Zarządzanie. Teoria i praktyka](https://www.empik.com/zarzadzanie-teoria-i-praktyka-kozminski-andrzej-k-piotrowski-wlodzimierz,prod14627907,ksiazka-p) — kind: book; author: Andrzej K. Koźmiński, Włodzimierz Piotrowski; year: 2013; podręcznik z którego polskie komisje licencjackie najczęściej czerpią ramę pytań kierunkowych.
- [How to study effectively (Cambridge University)](https://www.cam.ac.uk/news/how-to-study-effectively) — kind: article; oficjalna seria poradników akademickich; technika spaced repetition i interleaving.
- [The Pomodoro Technique — official site](https://francescocirillo.com/pages/pomodoro-technique) — kind: article; oficjalny opis techniki Pomodoro od jej twórcy Francesco Cirillo.

## Anatomia dobrej odpowiedzi egzaminacyjnej

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; struktura modelowej odpowiedzi egzaminacyjnej z zarządzania.
- [Praktyka zarządzania](https://www.empik.com/praktyka-zarzadzania-drucker-peter-f,prod37068999,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 2005; podejście „od zagadnienia do przykładu”, wzorzec myślenia menedżerskiego.
- [Wikipedia (PL) — Egzamin dyplomowy](https://pl.wikipedia.org/wiki/Egzamin_dyplomowy) — kind: article; struktura egzaminu licencjackiego/magisterskiego w polskim systemie szkolnictwa wyższego.

## Słownik kluczowych pojęć zarządzania

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; rozdział „Wprowadzenie do zarządzania”, definicje sprawności i skuteczności.
- [Kierowanie](https://ksiegarnia.pwn.pl/Kierowanie,67806624,p.html) — kind: book; author: James A. F. Stoner, R. Edward Freeman, Daniel R. Gilbert; year: 2011; klasyczne definicje organizacji, interesariuszy, zarządzania.
- [Wikipedia (PL) — Zarządzanie](https://pl.wikipedia.org/wiki/Zarządzanie) — kind: article; ścisłe definicje + linki do pojęć powiązanych.

## Klasycy zarządzania, których warto cytować

- [Praktyka zarządzania](https://www.empik.com/praktyka-zarzadzania-drucker-peter-f,prod37068999,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 2005; zarządzanie przez cele (MBO), pojęcie wiedzy jako zasobu.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; orientacja na klienta, 4P/5P, STP.
- [Strategia konkurencji](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; pięć sił, strategie generyczne.
- [Zarządzanie zasobami ludzkimi](https://www.empik.com/zarzadzanie-zasobami-ludzkimi-armstrong-michael-taylor-stephen,prod177953830,ksiazka-p) — kind: book; author: Michael Armstrong, Stephen Taylor; year: 2022; rola pracownika jako kluczowego zasobu.

## Pytanie 1: Podstawowe funkcje zarządzania

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; cztery funkcje zarządzania.
- [Wikipedia (PL) — Funkcje zarządzania](https://pl.wikipedia.org/wiki/Funkcje_zarządzania) — kind: article; planowanie, organizowanie, przewodzenie, kontrolowanie.
- [Encyclopaedia Britannica — Management](https://www.britannica.com/money/management) — kind: article; angielsko-języczna mapa funkcji zarządzania (POSDCORB Gulicka).
- [The Practice of Management — Drucker on MBO (HBR archive)](https://hbr.org/1976/01/what-results-should-you-expect-a-users-guide-to-mbo) — kind: article; year: 1976; klasyczny tekst HBR o MBO Druckera.

## Pytanie 2: Globalizacja a rynek światowy i lokalny

- [Wikipedia (PL) — Globalizacja](https://pl.wikipedia.org/wiki/Globalizacja) — kind: article; pojęcie, wymiary, procesy.
- [Globalization in Business — IMF Working Paper](https://www.imf.org/external/np/exr/ib/2008/053008.htm) — kind: article; year: 2008; oficjalne stanowisko MFW dot. globalizacji.
- [The World Is Flat. Brief History of the Twenty-First Century](https://www.empik.com/the-world-is-flat-friedman-thomas-l,prod37132867,ksiazka-p) — kind: book; author: Thomas L. Friedman; year: 2005; klasyczna analiza skutków globalizacji.

## Pytanie 3: Struktura kompetencji menedżerskich (Katz)

- [Skills of an Effective Administrator (Harvard Business Review)](https://hbr.org/1974/09/skills-of-an-effective-administrator) — kind: article; author: Robert L. Katz; year: 1974; oryginalny tekst Katza wprowadzający trójpodział kompetencji.
- [Wikipedia (PL) — Kompetencje menedżerskie](https://pl.wikipedia.org/wiki/Kompetencje_menedżerskie) — kind: article; klasyfikacje, model Katza.
- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; rozdziały o roli menedżera i jego kompetencjach.

## Pytanie 4: Przedsiębiorczość – pojęcie, cechy, uwarunkowania

- [Innovation and Entrepreneurship](https://www.empik.com/innovation-and-entrepreneurship-drucker-peter-f,prod37155824,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 1985; klasyczne ujęcie przedsiębiorczości jako „przesuwania zasobów do obszarów wyższej wydajności”.
- [Wikipedia (PL) — Przedsiębiorczość](https://pl.wikipedia.org/wiki/Przedsiębiorczość) — kind: article; ujęcie podmiotowe i przedmiotowe, cechy, determinanty.
- [PARP — Raport o stanie sektora MSP w Polsce](https://www.parp.gov.pl/component/publications/publication/raport-o-stanie-sektora-malych-i-srednich-przedsiebiorstw-w-polsce-2023) — kind: article; year: 2023; oficjalne dane o uwarunkowaniach przedsiębiorczości w Polsce.

## Pytanie 5: Konkurencyjność i przewaga konkurencyjna

- [Strategia konkurencji](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; pięć sił, strategie generyczne.
- [Competitive Advantage (HBR)](https://hbr.org/1996/11/what-is-strategy) — kind: article; author: Michael E. Porter; year: 1996; „What Is Strategy?” – tekst rozróżniający efektywność operacyjną od strategii.
- [Wikipedia (PL) — Przewaga konkurencyjna](https://pl.wikipedia.org/wiki/Przewaga_konkurencyjna) — kind: article; rodzaje przewagi (kosztowa, dyferencjacji, informacyjna).

## Pytanie 6: Działania nieetyczne i prewencja

- [Business Ethics — Stanford Encyclopedia of Philosophy](https://plato.stanford.edu/entries/ethics-business/) — kind: article; year: 2021; akademickie ujęcie etyki biznesu.
- [Ustawa o ochronie sygnalistów (Dziennik Ustaw)](https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20240000928) — kind: article; year: 2024; oficjalna polska ustawa o sygnalistach (whistleblowing).
- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; rozdział o etyce w zarządzaniu i odpowiedzialności społecznej.

## Pytanie 7: Systemy informatyczne w zarządzaniu

- [Wikipedia (EN) — Enterprise resource planning](https://en.wikipedia.org/wiki/Enterprise_resource_planning) — kind: article; ERP, historia, moduły.
- [Wikipedia (EN) — Customer relationship management](https://en.wikipedia.org/wiki/Customer_relationship_management) — kind: article; CRM, narzędzia, procesy.
- [SAP — What is ERP?](https://www.sap.com/products/erp/what-is-erp.html) — kind: article; oficjalna dokumentacja największego dostawcy ERP.
- [Salesforce — What is CRM?](https://www.salesforce.com/crm/what-is-crm/) — kind: article; oficjalne wprowadzenie do CRM.

## Pytanie 8: Otoczenie rynkowe przedsiębiorstwa

- [Wikipedia (PL) — Analiza PEST](https://pl.wikipedia.org/wiki/Analiza_PEST) — kind: article; makrootoczenie, PESTLE.
- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; otoczenie organizacji jako systemu otwartego.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; otoczenie marketingowe (mikro/makro).

## Pytanie 9: Czynniki zachowań konsumentów

- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; cztery grupy czynników: kulturowe, społeczne, osobiste, psychologiczne.
- [A Theory of Human Motivation (Psychological Review)](https://psycnet.apa.org/doi/10.1037/h0054346) — kind: paper; author: Abraham H. Maslow; year: 1943; oryginalna hierarchia potrzeb.
- [Wikipedia (PL) — Hierarchia potrzeb Maslowa](https://pl.wikipedia.org/wiki/Hierarchia_potrzeb) — kind: article; piramida potrzeb i jej krytyka.

## Pytanie 10: Analiza SWOT i TOWS

- [Wikipedia (PL) — Analiza SWOT](https://pl.wikipedia.org/wiki/Analiza_SWOT) — kind: article; macierz, czynniki wewnętrzne i zewnętrzne, cztery strategie.
- [Heinz Weihrich — The TOWS Matrix (Long Range Planning)](https://doi.org/10.1016/0024-6301(82)90120-0) — kind: paper; author: Heinz Weihrich; year: 1982; oryginalna publikacja wprowadzająca TOWS.
- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; SWOT jako punkt wyjścia do strategii rozwoju.

## Pytanie 11: Marketing tradycyjny vs współczesny

- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; ewolucja definicji marketingu, orientacja na klienta.
- [Marketing 4.0. Era cyfrowa](https://ksiegarnia.pwn.pl/Marketing-4.0,71082828,p.html) — kind: book; author: Philip Kotler, Hermawan Kartajaya, Iwan Setiawan; year: 2017; przejście od 1.0 do 4.0, marketing współczesny.
- [American Marketing Association — Definition of Marketing](https://www.ama.org/the-definition-of-marketing-what-is-marketing/) — kind: article; year: 2017; oficjalna definicja AMA.

## Pytanie 12: Metody i techniki organizatorskie

- [Wikipedia (PL) — Matryca Eisenhowera](https://pl.wikipedia.org/wiki/Matryca_Eisenhowera) — kind: article; podział zadań ważne/pilne.
- [The Pomodoro Technique — official site](https://francescocirillo.com/pages/pomodoro-technique) — kind: article; oficjalna prezentacja techniki Pomodoro.
- [Wikipedia (PL) — Analiza wartości](https://pl.wikipedia.org/wiki/Analiza_wartości) — kind: article; metoda badania funkcji elementów w celu obniżenia kosztów.

## Pytanie 13: Elementy planu marketingowego

- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; struktura planu marketingowego, STP, 4P/5P, KPI.
- [Wikipedia (EN) — SMART criteria](https://en.wikipedia.org/wiki/SMART_criteria) — kind: article; pięć kryteriów celu SMART.
- [Marketing Plan Handbook](https://www.empik.com/the-marketing-plan-handbook-wood-marian-burk,prod14600025,ksiazka-p) — kind: book; author: Marian Burk Wood; year: 2017; standardowy podręcznik z szablonem planu marketingowego.

## Pytanie 14: Strategie cenowe i ich determinanty

- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; rozdział o polityce cenowej, skimming i penetracji.
- [Wikipedia (EN) — Pricing strategies](https://en.wikipedia.org/wiki/Pricing_strategies) — kind: article; klasyfikacja strategii cenowych.
- [Wikipedia (PL) — Skimming](https://pl.wikipedia.org/wiki/Strategia_zbierania_śmietanki) — kind: article; strategia zbierania śmietanki.

## Pytanie 15: Cykl życia produktu

- [Wikipedia (PL) — Cykl życia produktu](https://pl.wikipedia.org/wiki/Cykl_życia_produktu) — kind: article; cztery fazy i działania przedsiębiorstwa.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; rozdział o zarządzaniu cyklem życia produktu.
- [Theodore Levitt — Exploit the Product Life Cycle (HBR)](https://hbr.org/1965/11/exploit-the-product-life-cycle) — kind: article; author: Theodore Levitt; year: 1965; klasyczny tekst HBR o cyklu życia.

## Pytanie 16: Narzędzia zintegrowanej komunikacji marketingowej

- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; rozdział o IMC, mix komunikacyjny.
- [Wikipedia (EN) — Integrated marketing communications](https://en.wikipedia.org/wiki/Integrated_marketing_communications) — kind: article; ewolucja IMC, narzędzia.
- [American Marketing Association — IMC](https://www.ama.org/topics/integrated-marketing-communications/) — kind: article; oficjalne stanowisko AMA.

## Pytanie 17: Klasyfikacja kosztów w rachunkowości

- [Ustawa o rachunkowości (Dziennik Ustaw)](https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19941210591) — kind: article; year: 1994; oficjalna polska podstawa prawna klasyfikacji kosztów.
- [Wikipedia (PL) — Koszty stałe i zmienne](https://pl.wikipedia.org/wiki/Koszty_stałe_i_zmienne) — kind: article; podział wg zmienności, próg rentowności.
- [Rachunkowość finansowa i podatkowa](https://ksiegarnia.pwn.pl/Rachunkowosc-finansowa-i-podatkowa,67817620,p.html) — kind: book; author: Irena Olchowicz; year: 2018; standardowy polski podręcznik akademicki.

## Pytanie 18: Biznesplan – struktura i funkcje

- [PARP — Jak napisać biznesplan?](https://www.parp.gov.pl/component/content/article/56186:jak-napisac-biznesplan) — kind: article; year: 2022; oficjalny przewodnik PARP po strukturze biznesplanu.
- [Wikipedia (PL) — Biznesplan](https://pl.wikipedia.org/wiki/Biznesplan) — kind: article; struktura, funkcje, zastosowania.
- [Innovation and Entrepreneurship](https://www.empik.com/innovation-and-entrepreneurship-drucker-peter-f,prod37155824,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 1985; cechy skutecznego biznesplanu (realizm, kompletność, mierzalność).

## Pytanie 19: Wizja, misja i strategia organizacji

- [Built to Last: Successful Habits of Visionary Companies](https://www.empik.com/built-to-last-successful-habits-of-visionary-companies-collins-jim,prod14620311,ksiazka-p) — kind: book; author: Jim Collins, Jerry I. Porras; year: 2004; klasyczne ujęcie wizji i misji firm wizjonerskich.
- [What Is Strategy? (HBR)](https://hbr.org/1996/11/what-is-strategy) — kind: article; author: Michael E. Porter; year: 1996; rozróżnienie strategii od efektywności operacyjnej.
- [Wikipedia (PL) — Misja organizacji](https://pl.wikipedia.org/wiki/Misja_organizacji) — kind: article; różnice między misją a wizją z polskimi przykładami.

## Pytanie 20: Istota i rodzaje strategii przedsiębiorstwa

- [Strategia konkurencji](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; strategie generyczne.
- [Strategies for Diversification (HBR)](https://hbr.org/1957/09/strategies-for-diversification) — kind: article; author: H. Igor Ansoff; year: 1957; oryginalna macierz Ansoffa.
- [Wikipedia (PL) — Macierz Ansoffa](https://pl.wikipedia.org/wiki/Macierz_Ansoffa) — kind: article; cztery strategie kierunków rozwoju.

## Pytanie 21: Zarządzanie projektami we współczesnych organizacjach

- [Project Management Institute — PMBOK Guide](https://www.pmi.org/pmbok-guide-standards) — kind: article; year: 2021; standard PMBOK 7. ed. (PMI).
- [Manifesto for Agile Software Development](https://agilemanifesto.org/) — kind: article; year: 2001; oficjalny manifest Agile (4 wartości, 12 zasad).
- [Scrum Guide (oficjalna)](https://scrumguides.org/scrum-guide.html) — kind: article; year: 2020; oficjalna specyfikacja Scrum (Schwaber, Sutherland).

## Pytanie 22: Funkcje i narzędzia ZZL

- [Zarządzanie zasobami ludzkimi](https://www.empik.com/zarzadzanie-zasobami-ludzkimi-armstrong-michael-taylor-stephen,prod177953830,ksiazka-p) — kind: book; author: Michael Armstrong, Stephen Taylor; year: 2022; cykl życia pracownika, narzędzia, modele kompetencji.
- [Wikipedia (PL) — Zarządzanie zasobami ludzkimi](https://pl.wikipedia.org/wiki/Zarządzanie_zasobami_ludzkimi) — kind: article; funkcje ZZL, polski kontekst.
- [SHRM — Behavioral Interviewing (STAR)](https://www.shrm.org/topics-tools/news/talent-acquisition/behavioral-interviewing) — kind: article; oficjalny opis techniki STAR od SHRM.

## Pytanie 23: Teorie i instrumenty motywowania

- [A Theory of Human Motivation](https://psycnet.apa.org/doi/10.1037/h0054346) — kind: paper; author: Abraham H. Maslow; year: 1943; oryginalna hierarchia potrzeb.
- [One More Time: How Do You Motivate Employees? (HBR)](https://hbr.org/2003/01/one-more-time-how-do-you-motivate-employees) — kind: article; author: Frederick Herzberg; year: 1968 (HBR reprint 2003); teoria dwuczynnikowa.
- [The Human Side of Enterprise](https://www.empik.com/the-human-side-of-enterprise-mcgregor-douglas,prod14582820,ksiazka-p) — kind: book; author: Douglas McGregor; year: 1960; teorie X i Y.
- [Work and Motivation](https://www.empik.com/work-and-motivation-vroom-victor-h,prod14613555,ksiazka-p) — kind: book; author: Victor H. Vroom; year: 1964; teoria oczekiwań.

## Pytanie 24: Klasyczne i nowoczesne struktury organizacyjne

- [Wikipedia (PL) — Struktura organizacyjna](https://pl.wikipedia.org/wiki/Struktura_organizacyjna) — kind: article; klasyczne i nowoczesne struktury.
- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; rozdział „Projektowanie organizacji”.
- [Structure in Fives: Designing Effective Organizations](https://www.empik.com/structure-in-fives-designing-effective-organizations-mintzberg-henry,prod14584466,ksiazka-p) — kind: book; author: Henry Mintzberg; year: 1983; pięć typów konfiguracji organizacyjnych Mintzberga.

## Pytanie 25: Style kierowania menedżerów

- [Patterns of Aggressive Behavior in Experimentally Created “Social Climates”](https://doi.org/10.1080/00224545.1939.9713366) — kind: paper; author: Kurt Lewin, Ronald Lippitt, Ralph K. White; year: 1939; oryginalne badanie wprowadzające trójpodział stylów.
- [Wikipedia (PL) — Style kierowania](https://pl.wikipedia.org/wiki/Styl_kierowania) — kind: article; autokratyczny, demokratyczny, liberalny.
- [Leadership That Gets Results (HBR)](https://hbr.org/2000/03/leadership-that-gets-results) — kind: article; author: Daniel Goleman; year: 2000; sześć stylów przywództwa Golemana (rozszerzenie klasyki Lewina).

## Pytanie 26: Zasady gospodarki rynkowej

- [Wikipedia (PL) — Gospodarka rynkowa](https://pl.wikipedia.org/wiki/Gospodarka_rynkowa) — kind: article; podstawowe zasady, samoregulacja.
- [Mikroekonomia (PWN)](https://ksiegarnia.pwn.pl/Mikroekonomia,67790824,p.html) — kind: book; author: David Begg, Stanley Fischer, Rudiger Dornbusch; year: 2014; klasyczny podręcznik akademicki.
- [Encyclopaedia Britannica — Market economy](https://www.britannica.com/money/market-economy) — kind: article; ujęcie encyklopedyczne.

## Pytanie 27: Plan Balcerowicza – skutki społeczne i gospodarcze

- [Wikipedia (PL) — Plan Balcerowicza](https://pl.wikipedia.org/wiki/Plan_Balcerowicza) — kind: article; filary planu, kalendarium reform.
- [800 dni. Szok kontrolowany](https://www.empik.com/800-dni-szok-kontrolowany-balcerowicz-leszek,prod14604076,ksiazka-p) — kind: book; author: Leszek Balcerowicz; year: 1992; relacja autora reform.
- [NBP — Inflacja w Polsce 1989–2000 (raport)](https://www.nbp.pl/publikacje/o_inflacji/inflacja_w_polsce_1989_2000.pdf) — kind: article; oficjalny raport NBP o stłumieniu hiperinflacji.

## Pytanie 28: Podatki, dotacje i kredyty rządowe

- [Ministerstwo Finansów — Podatki w Polsce](https://www.podatki.gov.pl/) — kind: article; oficjalny portal informacji podatkowej (CIT, PIT, VAT).
- [BGK — Programy gwarancyjne](https://www.bgk.pl/przedsiebiorstwa/) — kind: article; oficjalne preferencyjne kredyty i gwarancje BGK.
- [PARP — Dotacje dla firm](https://www.parp.gov.pl/component/grants/grants) — kind: article; oficjalna baza dotacji dla przedsiębiorstw.

## Pytanie 29: Cła ochronne, ceny minimalne i maksymalne

- [Wikipedia (PL) — Cło](https://pl.wikipedia.org/wiki/Cło) — kind: article; rodzaje ceł, skutki gospodarcze.
- [Wikipedia (PL) — Cena maksymalna](https://pl.wikipedia.org/wiki/Cena_maksymalna) — kind: article; skutki cen administracyjnych, niedobory.
- [Mikroekonomia (PWN)](https://ksiegarnia.pwn.pl/Mikroekonomia,67790824,p.html) — kind: book; author: David Begg, Stanley Fischer, Rudiger Dornbusch; year: 2014; rozdział o interwencji państwa na rynku.

## Pytanie 30: Krótko- i długoterminowe efekty inflacji

- [NBP — Czym jest inflacja?](https://nbp.pl/edukacja/inflacja/) — kind: article; oficjalna edukacja NBP o inflacji.
- [Wikipedia (PL) — Inflacja](https://pl.wikipedia.org/wiki/Inflacja) — kind: article; przyczyny, skutki, redystrybucja.
- [Makroekonomia (PWN)](https://ksiegarnia.pwn.pl/Makroekonomia,67790849,p.html) — kind: book; author: David Begg, Stanley Fischer, Rudiger Dornbusch; year: 2014; mechanizmy inflacyjne.

## Pytanie DM 1: Model POEM (Paid, Owned, Earned Media)

- [IAB Polska — Raport „AdEx”](https://www.iab.org.pl/wszystkie-publikacje/) — kind: article; year: 2024; oficjalne raporty branżowe IAB Polska.
- [HubSpot — Paid, Owned, and Earned Media](https://blog.hubspot.com/marketing/paid-earned-and-owned-media) — kind: article; oficjalny blog HubSpot, klasyfikacja POEM.
- [Wikipedia (EN) — Paid, owned and earned media](https://en.wikipedia.org/wiki/Paid_owned_and_earned_media) — kind: article; pochodzenie modelu i ewolucja.

## Pytanie DM 2: Multichannel, Cross-Channel, Omnichannel

- [Harvard Business Review — Creating the Optimal Omnichannel Experience](https://hbr.org/2017/01/a-study-of-46000-shoppers-shows-that-omnichannel-retailing-works) — kind: article; year: 2017; badanie HBR o 46 000 klientów i omnichannel.
- [Salesforce — What is Omnichannel?](https://www.salesforce.com/resources/articles/omnichannel/) — kind: article; oficjalna definicja Salesforce.
- [Wikipedia (EN) — Omnichannel retailing](https://en.wikipedia.org/wiki/Omnichannel_retailing) — kind: article; różnice między multichannel/cross-channel/omnichannel.

## Pytanie DM 3: Etapy tworzenia strategii mediowej

- [IAB Polska — Standardy planowania mediów](https://www.iab.org.pl/standardy-i-dobre-praktyki/) — kind: article; oficjalne standardy IAB.
- [Think with Google — Media planning](https://www.thinkwithgoogle.com/intl/en-cee/marketing-strategies/) — kind: article; oficjalne materiały Google dot. planowania mediów.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; strategia komunikacji – etap planowania mediów.

## Pytanie DM 4: Rodzaje kampanii mediowych według celów

- [Google Ads Help — Choose your campaign goal](https://support.google.com/google-ads/answer/9510373) — kind: article; oficjalna lista celów kampanii w Google Ads.
- [Meta Business Help Center — Campaign objectives](https://www.facebook.com/business/help/1438417719786914) — kind: article; oficjalne cele kampanii Meta (świadomość, ruch, zaangażowanie, sprzedaż).
- [Wikipedia (EN) — Marketing communications](https://en.wikipedia.org/wiki/Marketing_communications) — kind: article; klasyfikacja kampanii w kontekście celu marketingowego.

## Pytanie DM 5: Rynek programatyczny – DSP, SSP, DMP, AdEx

- [IAB Tech Lab — OpenRTB Specification](https://iabtechlab.com/standards/openrtb/) — kind: article; oficjalna specyfikacja Real-Time Bidding.
- [Wikipedia (EN) — Real-time bidding](https://en.wikipedia.org/wiki/Real-time_bidding) — kind: article; mechanizm aukcji, role DSP/SSP/DMP/AdEx.
- [Google — Authorized Buyers (Display & Video 360)](https://support.google.com/displayvideo/answer/2941040) — kind: article; oficjalna dokumentacja Google dot. programmatic.

## Pytanie DM 6: Kreacja display – awareness vs performance

- [IAB — Display Advertising Guidelines](https://www.iab.com/guidelines/display-creative-guidelines/) — kind: article; oficjalne wytyczne IAB dla kreacji display.
- [Google Ads Help — Display ad best practices](https://support.google.com/google-ads/answer/7679871) — kind: article; oficjalne wytyczne Google dla reklam display.
- [Think with Google — Effective creative](https://www.thinkwithgoogle.com/feature/ads-creative-effectiveness/) — kind: article; raport Google o skutecznej kreacji reklamowej.

## Pytanie DM 7: SEO on-site

- [Google Search Central — SEO Starter Guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide) — kind: article; oficjalny przewodnik Google po SEO on-site.
- [Web.dev — Lighthouse and Core Web Vitals](https://web.dev/articles/vitals) — kind: article; oficjalne wytyczne Google dot. wydajności i Core Web Vitals.
- [Moz — Beginner's Guide to SEO](https://moz.com/beginners-guide-to-seo) — kind: article; klasyczny darmowy przewodnik branżowy.

## Pytanie DM 8: Google Ads i dobór słów kluczowych

- [Google Ads Help — Keyword Planner](https://support.google.com/google-ads/answer/7337243) — kind: article; oficjalna dokumentacja Keyword Planner.
- [Google Ads Help — Keyword match types](https://support.google.com/google-ads/answer/7478529) — kind: article; oficjalne typy dopasowania (broad, phrase, exact).
- [Google Trends — About](https://support.google.com/trends/answer/4365533) — kind: article; oficjalna dokumentacja Google Trends.

## Pytanie DM 9: Prawa autorskie osobiste vs majątkowe

- [Ustawa o prawie autorskim i prawach pokrewnych (Dziennik Ustaw)](https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19940240083) — kind: article; year: 1994; oficjalna podstawa prawna w Polsce.
- [Ministerstwo Kultury — Prawo autorskie](https://www.gov.pl/web/kultura/prawo-autorskie) — kind: article; oficjalne wyjaśnienia rządowe.
- [Wikipedia (PL) — Prawo autorskie](https://pl.wikipedia.org/wiki/Prawo_autorskie) — kind: article; podział na osobiste i majątkowe, czas trwania.

## Pytanie DM 10: Content marketing – rodzaje treści i kanały

- [Content Marketing Institute — What Is Content Marketing?](https://contentmarketinginstitute.com/what-is-content-marketing/) — kind: article; oficjalna definicja CMI.
- [HubSpot — The Ultimate Guide to Content Marketing](https://www.hubspot.com/content-marketing) — kind: article; wytyczne HubSpot, formaty treści.
- [Wikipedia (EN) — Content marketing](https://en.wikipedia.org/wiki/Content_marketing) — kind: article; rodzaje, kanały, historia.

## Pytanie DM 11: Profile użytkowników i reklamy na 3 platformach SM

- [Meta Business Help Center — Facebook & Instagram Ads](https://www.facebook.com/business/help) — kind: article; oficjalne dane reklamowe Meta.
- [TikTok for Business — Ad formats](https://ads.tiktok.com/business/en/solutions/ads) — kind: article; oficjalne formaty reklamowe TikTok.
- [DataReportal — Digital Global Overview](https://datareportal.com/reports/digital-2024-global-overview-report) — kind: article; year: 2024; oficjalny coroczny raport o demografii użytkowników platform.

## Pytanie DM 12: Analiza skuteczności e-mail marketingu

- [Mailchimp — Email Marketing Benchmarks](https://mailchimp.com/resources/email-marketing-benchmarks/) — kind: article; oficjalne benchmarki branżowe Mailchimp.
- [HubSpot — Email Marketing Metrics](https://blog.hubspot.com/marketing/email-marketing-metrics) — kind: article; metryki i KPI w e-mail marketingu.
- [Wikipedia (EN) — Email marketing](https://en.wikipedia.org/wiki/Email_marketing) — kind: article; metryki i wskaźniki, A/B testing.

## Pytanie DM 13: Budowanie bazy e-mail marketingowej

- [RODO – Rozporządzenie 2016/679 (EUR-Lex)](https://eur-lex.europa.eu/legal-content/PL/TXT/?uri=CELEX:32016R0679) — kind: article; year: 2016; oficjalna podstawa prawna RODO/GDPR (zgoda na komunikację marketingową).
- [Mailchimp — How to Grow Your Email List](https://mailchimp.com/resources/grow-email-list/) — kind: article; oficjalne porady Mailchimp dot. budowania bazy.
- [GetResponse — Lead Magnets Guide](https://www.getresponse.com/blog/lead-magnets) — kind: article; oficjalne praktyki polskiego dostawcy SaaS e-mailowego.

## Pytanie DM 14: Heurystyki Nielsena

- [Nielsen Norman Group — 10 Usability Heuristics](https://www.nngroup.com/articles/ten-usability-heuristics/) — kind: article; author: Jakob Nielsen; year: 1994 (aktualizacja 2020); oficjalne źródło 10 heurystyk.
- [Don't Make Me Think (Krug)](https://www.empik.com/dont-make-me-think-revisited-krug-steve,prod14620315,ksiazka-p) — kind: book; author: Steve Krug; year: 2014; klasyczna książka o user experience i użyteczności.
- [Interaction Design Foundation — Heuristic Evaluation](https://www.interaction-design.org/literature/topics/heuristic-evaluation) — kind: article; akademickie kompendium heurystyk Nielsena.

## Pytanie DM 15: Mechanizm emisji reklam internetowych

- [IAB Tech Lab — OpenRTB Specification](https://iabtechlab.com/standards/openrtb/) — kind: article; oficjalna specyfikacja aukcji RTB.
- [IAB — Viewability Standards](https://www.iab.com/guidelines/iab-measurement-guidelines/) — kind: article; oficjalne standardy widoczności reklamy (MRC, IAB).
- [Google Ads Help — Conversion tracking](https://support.google.com/google-ads/answer/1722022) — kind: article; oficjalny opis pomiaru konwersji i raportowania.

## Mini-słownik dodatkowych pojęć z literatury

- [Praktyka zarządzania](https://www.empik.com/praktyka-zarzadzania-drucker-peter-f,prod37068999,ksiazka-p) — kind: book; author: Peter F. Drucker; year: 2005; pojęcia MBO, knowledge worker, marketing.
- [Strategia konkurencji](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; pojęcia łańcucha wartości, strategii generycznych.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; pojęcia marketingu, STP, CRM, customer journey.
- [Zarządzanie zasobami ludzkimi](https://www.empik.com/zarzadzanie-zasobami-ludzkimi-armstrong-michael-taylor-stephen,prod177953830,ksiazka-p) — kind: book; author: Michael Armstrong, Stephen Taylor; year: 2022; pojęcia HRM, ATS, talent management.

## Mapa zależności tematycznych pytań

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; integracja funkcji zarządzania, strategii i ZZL.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; integracja marketingu z biznesplanem i strategią.
- [Zarządzanie. Teoria i praktyka](https://www.empik.com/zarzadzanie-teoria-i-praktyka-kozminski-andrzej-k-piotrowski-wlodzimierz,prod14627907,ksiazka-p) — kind: book; author: Andrzej K. Koźmiński, Włodzimierz Piotrowski; year: 2013; przekrojowe ujęcie powiązań tematycznych.

## Symulacja obrony – losowe pytanie

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; ramy odpowiedzi na pytania kierunkowe.
- [Wikipedia (PL) — Egzamin dyplomowy](https://pl.wikipedia.org/wiki/Egzamin_dyplomowy) — kind: article; struktura obrony licencjackiej.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; baza pytań marketingowych.

## Najczęstsze pytania dodatkowe komisji

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; pytania pogłębiające z różnic sprawność/skuteczność, funkcji zarządzania.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; pytania pogłębiające z marketingu klasycznego i digital.
- [Strategia konkurencji](https://www.empik.com/strategia-konkurencji-metody-analizy-sektorow-i-konkurentow-porter-michael-e,prod14595415,ksiazka-p) — kind: book; author: Michael E. Porter; year: 2006; pytania pogłębiające z konkurencji i strategii.

## Powtórka błyskawiczna – fiszki z 45 pytań

- [Podstawy zarządzania organizacjami](https://ksiegarnia.pwn.pl/Podstawy-zarzadzania-organizacjami,67806788,p.html) — kind: book; author: Ricky W. Griffin; year: 2017; baza pojęć z zarządzania ogólnego.
- [Marketing](https://ksiegarnia.pwn.pl/Marketing,68663624,p.html) — kind: book; author: Philip Kotler, Kevin Lane Keller; year: 2017; baza pojęć marketingowych.
- [IAB Polska — Słowniczek pojęć](https://www.iab.org.pl/baza-wiedzy/slowniczek-pojec/) — kind: article; oficjalny słownik branżowy IAB Polska (digital marketing).

## Checklist na dzień obrony

- [Wikipedia (PL) — Egzamin dyplomowy](https://pl.wikipedia.org/wiki/Egzamin_dyplomowy) — kind: article; przebieg obrony, regulamin.
- [Cambridge — How to study effectively](https://www.cam.ac.uk/news/how-to-study-effectively) — kind: article; oficjalny przewodnik akademicki – ostatnie 24h przed egzaminem.
- [The Pomodoro Technique — official site](https://francescocirillo.com/pages/pomodoro-technique) — kind: article; technika pracy w blokach na ostatnie powtórki.

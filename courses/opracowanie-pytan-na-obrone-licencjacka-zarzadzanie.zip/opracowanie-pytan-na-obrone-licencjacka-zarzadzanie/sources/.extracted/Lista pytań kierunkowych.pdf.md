--- page 1 ---

Lista pytań kierunkowych (Zarządzanie):
1. Wymień i omów podstawowe funkcje zarządzania.
Współczesna nauka o zarządzaniu (opierając się na klasycznej szkole, m.in. na
literaturze R.W. Griffina czy J. Stonera) definiuje zarządzanie jako zestaw działań
skierowanych na zasoby organizacji, aby osiągnąć cele w sposób sprawny i
skuteczny.
Te działania to cztery podstawowe funkcje:
1. Planowanie (Fundament): Jest to najważniejsza funkcja, od której wszystko
się zaczyna. Polega na wyborze celów i określeniu działań niezbędnych do ich
realizacji. Identyfikacja aktualnych problemów przedsiębiorstwa do głębi
analiza bieżącej placówki określenie kryteriów rozwoju.W zarządzaniu
dzielimy planowanie na strategiczne (długookresowe, np. wejście firmy na
nowy rynek) oraz operacyjne (bieżące zadania), taktyczne (średni okres na
przykład plan kampanii)
Planowanie zaczynamy od analizy otoczenia i wnętrza firmy na przykład metodą
SWOT a dopiero potem wyznaczamy cele Smart.
●	
Przykład marketingowy: To tutaj decydujemy, czy naszym celem jest
budowa świadomości marki, czy bezpośrednia sprzedaż.
2. Organizowanie (Struktura): To proces porządkowania zasobów i działań.
Manager decyduje, jak podzielić pracę, kto ma jakie uprawnienia i jakie
zasoby (pieniądze, czas, technologię) przypisać do konkretnych zadań.
Chodzi o stworzenie struktury, która pozwoli zrealizować plan.
●	
Przykład marketingowy: To podział ról w zespole – np. oddzielenie
działu kreacji od działu analityki danych.
3. Przewodzenie / Kierowanie (Czynnik ludzki): Funkcja ta obejmuje
motywowanie pracowników, rozwiązywanie konfliktów i komunikację. Celem
jest sprawienie, by ludzie chcieli angażować się w realizację celów firmy. Jak
podkreślał Peter Drucker, kluczowe jest tu zarządzanie przez cele (MBO).

--- page 2 ---

●	
Przykład marketingowy: Manager musi zainspirować zespół do
stworzenia nieszablonowej kampanii, dbając o ich kreatywność i
uniknięcie wypalenia.
4. Kontrolowanie (Weryfikacja): To zamykający etap, który polega na
mierzeniu postępów i porównywaniu wyników z założonym planem. Jeśli
pojawiają się odchylenia, manager musi podjąć działania korygujące. Kontrola
nie służy „karaniu”, ale usprawnianiu procesów na przyszłość.
●	
Przykład marketingowy: Analiza raportów z kampanii – jeśli koszt
pozyskania klienta jest za wysoki, wracamy do planowania i
zmieniamy strategię.
Podsumowanie: Warto zaznaczyć, że te funkcje nie następują po sobie sztywno
jedna po drugiej, lecz przenikają się nawzajem, tworząc ciągły proces zarządczy.
Dodatkowo:
Czym różni się sprawność od skuteczności?
Skuteczność: To robienie właściwych rzeczy (osiągnięcie celu, np. Sprzedaliśmy
tyle, ile planowaliśmy). Sprawność: To robienie rzeczy we właściwy sposób
(osiągnięcie celu przy jak najmniejszym zużyciu zasobów, np. Sprzedaliśmy tyle
samo, ale wydaliśmy połowę budżetu).
Która funkcja zarządzania jest najważniejsza i dlaczego?
Najważniejszą funkcją jest planowanie, ponieważ wyznacza kierunek działania całej
organizacji. Bez jasno określonych celów nie ma sensu ani organizowanie zasobów,
ani kontrolowanie wyników.
Dlaczego czynnik ludzki jest tak ważny w zarządzaniu?
Nawet najlepiej zaplanowana strategia nie przyniesie efektów bez zaangażowanych
pracowników. Jak wskazuje Armstrong, to ludzie są kluczowym zasobem organizacji,
a skuteczne zarządzanie polega na tworzeniu warunków, w których pracownicy chcą
realizować cele firmy.

--- page 3 ---

2. Omów jak procesy globalizacji oddziałują na rynek światowy i
rynki lokalne.
Globalizacja to proces integrowania się rynków krajowych w jeden współzależny
rynek światowy. W literaturze zarządczej (np. U Stone’a) podkreśla się, że proces ten
skraca dystans i zaciera granice w przepływie towarów, usług, kapitału i informacji.
Oddziaływanie na rynek światowy:
 Standaryzacja produktów: Firmy tworzą uniwersalne produkty (np.
Oprogramowanie, elektronika), co pozwala im wykorzystać tzw. Korzyści skali
– im więcej produkują na świat, tym niższy jest koszt jednostkowy.
 Wzrost konkurencyjności: Granice przestają chronić lokalnych producentów.
Na rynku światowym wygrywają podmioty najbardziej innowacyjne i efektywne
kosztowo.
 Łańcuchy dostaw: produkcja jest rozproszona geograficznie poszczególne
etapy wytworzenia produktu odbywają się w różnych krajach w celu
optymalizacji kosztów.
 Gospodarki są od siebie zależne kryzys w jednym kraju może wpłynąć na inne
Oddziaływanie na rynki lokalne:
 Dyfuzja innowacji: Na rynki lokalne szybciej trafiają nowoczesne technologie i
standardy zarządzania z krajów wysoko rozwiniętych.
 Presja na lokalnych producentów: Lokalne firmy muszą podnosić jakość lub
obniżać ceny, aby przetrwać w starciu z globalnymi korporacjami.
 Zmiana postaw konsumenckich: Globalizacja prowadzi do ujednolicenia
gustów (konsumpcjonizm), ale jednocześnie wywołuje reakcję obronną w
postaci etnocentryzmu konsumenckiego (kupowanie produktów rodzimych,
np. Moda na „polskie rzemiosło”).

--- page 4 ---

 Zmiana rynku pracy z jednej strony pojawiają się nowe miejsca w
zagranicznych firmach, ale z drugiej strony rośnie presja efektywności co
może prowadzić do redukcji zatrudnienia w lokalnych firmach nieodpornych na
konkurencjie.
Podsumowanie: Globalizacja niesie zarówno szanse, jak i zagrożenia, dlatego
kluczowym wyzwaniem dla współczesnych organizacji jest umiejętne balansowanie
między efektywnością globalną a wrażliwością lokalną.
Dodatkowo:
Czym jest "outsourcing" w kontekście globalizacji?
● Odpowiedź: To zlecanie części procesów firmy (np. obsługi klienta lub IT)
podmiotom zewnętrznym, często w krajach o niższych kosztach pracy (np.
Indie, Polska), co jest bezpośrednim efektem globalizacji.
3. Przedstaw strukturę kompetencji menedżerskich i scharakteryzuj
3 wybrane.
Kompetencje menedżerskie to połączenie wiedzy, umiejętności i postaw, które
pozwalają skutecznie realizować funkcje zarządzania. Według klasycznej koncepcji
Roberta Katza, strukturę tych kompetencji dzielimy na trzy główne grupy, a ich
znaczenie zmienia się w zależności od szczebla zarządzania.
 Struktura kompetencji (Model Katza):
o Kompetencje techniczne: Znajomość konkretnych narzędzi i metod
pracy (np. Obsługa systemu reklamowego w digital marketingu).
o Kompetencje społeczne (interpersonalne): Umiejętność pracy z ludźmi,
komunikacji i motywowania.
o Kompetencje koncepcyjne: Umiejętność abstrakcyjnego myślenia,
widzenia firmy jako całości i przewidywania zmian rynkowych.

--- page 5 ---

 Charakterystyka 3 wybranych kompetencji:
o Kompetencje społeczne (Interpersonalne): Są kluczowe na każdym
szczeblu zarządzania. Menadżer musi potrafić budować relacje,
rozwiązywać konflikty i efektywnie komunikować cele. W dobie pracy
zdalnej i rozproszonych zespołów marketingowych, umiejętność
jasnego przekazywania feedbacku (informacji zwrotnej) staje się
fundamentem efektywności.
o Kompetencje koncepcyjne: Polegają na postrzeganiu organizacji w
sposób systemowy. Menadżer z takimi kompetencjami potrafi
zrozumieć, jak zmiana w jednym dziale (np. Obcięcie budżetu na IT)
wpłynie na inny (np. Wydajność kampanii sprzedażowych). Są one
najważniejsze dla wyższej kadry zarządzającej (Top Management),
ponieważ odpowiadają za strategię długoterminową.
o Kompetencje techniczne: To wiedza specjalistyczna niezbędna do
wykonania konkretnych zadań. Na niższych szczeblach zarządzania
(np. Team Leader zespołu SEO) menadżer musi posiadać wysokie
umiejętności techniczne, aby móc merytorycznie wspierać swój zespół i
oceniać jakość ich pracy. Bez nich trudno o autorytet w zespole
eksperckim.
Podsumowując, skuteczny menedżer powinien łączyć wszystkie trzy rodzaje
kompetencji, dostosowując ich proporcje do poziomu zarządzania i specyfiki
organizacji.
4. Przedsiębiorczość – pojęcie, cechy i uwarunkowania rozwoju we
współczesnych gospodarkach.
Pojęcie przedsiębiorczości (Co to jest?): W literaturze zarządzania
przedsiębiorczość definiuje się na dwa sposoby:
● W ujęciu przedmiotowym: To proces tworzenia nowej organizacji (zakładanie
firmy) i podejmowanie ryzyka ekonomicznego.

--- page 6 ---

● W ujęciu podmiotowym (według Druckera): To specyficzna cecha
zachowania – umiejętność dostrzegania szans tam, gdzie inni widzą problemy,
oraz zdolność do wprowadzania innowacji. Przedsiębiorca to ktoś, kto
„przesuwa zasoby z obszarów niższej wydajności do obszarów wyższej
wydajności”.
Cechy przedsiębiorcy (Jaki on jest?):
Cechy przedsiębiorczości odnoszą się do cech osoby przedsiębiorczej!
● Innowacyjność: Chęć do wprowadzania nowych rozwiązań (nie tylko
produktów, ale i procesów).
● Skłonność do podejmowania ryzyka: ryzyka skalkulowanego (opartego na
analizie).
● Asertywność i determinacja: Wiara we własne siły i dążenie do celu mimo
porażek.
● Elastyczność: Umiejętność adaptacji do szybko zmieniającego się otoczenia
rynkowego.
Uwarunkowania rozwoju we współczesnych gospodarkach (Co sprzyja
przedsiębiorczości?):
Współczesna gospodarka (oparta na wiedzy) narzuca specyficzne warunki:
● Technologia i Cyfryzacja: Obniżenie barier wejścia. Dziś, dzięki internetowi,
koszt rozpoczęcia biznesu jest znacznie niższy niż kiedyś. Rozwój nowych
technologii
● Otoczenie instytucjonalne: To, czy państwo pomaga (dotacje, niskie podatki,
proste prawo), czy przeszkadza (biurokracja). Stabilność ekonomiczna.
● Kapitał ludzki: Dostęp do wykształconych pracowników i wiedzy (know-how).
● Globalizacja: Możliwość skalowania biznesu na cały świat od pierwszego
dnia działalności.
● Uwarunkowanie prawne proste procedury zakładania firmy

--- page 7 ---

● Poziom edukacji
5. Wyjaśnij czym jest konkurencyjność i przewaga konkurencyjna i
wskaż ich determinanty.
● Konkurencyjność: To zdolność firmy do rywalizacji. To potencjał, jaki firma
posiada, by utrzymać się na rynku i sprostać innym graczom.
● Przewaga konkurencyjna: To efekt, czyli coś, co sprawia, że firma jest
lepsza od innych w konkretnym obszarze. To coś, co klient widzi i za co
wybiera naszą firmę, a nie konkurencję.
Rodzaje przewagi konkurencyjnej (według M. Portera): Porter twierdzi, że
przewagę buduje się głównie na dwa sposoby:
● Przewaga kosztowa (Lider kosztowy): Firma potrafi wytworzyć produkt
taniej niż inni (np. dzięki skali produkcji). Dzięki temu może oferować niższe
ceny (np. Ryanair, IKEA)
● Przewaga jakościowa (Zróżnicowanie / Dyferencjacja): Firma oferuje coś
unikalnego, za co klient jest gotów zapłacić więcej (np. marka, design,
technologia, obsługa). Przykładem jest Apple – płacimy za ekosystem i
prestiż.
● Przewaga informacyjna: wiąże się z procesami kreowania i przekazywania
informacji może pełnić funkcję wsparcia przewagi jakościowej czy
informowanie nabywcy o wyższej jakości produktów lub niższej i kształtowanie
preferencji nabywców, czyli pływanie na preferencje i zachowania poprzez
skuteczną komunikację.
Determinanty konkurencyjności
 Determinanty wewnętrzne (endogeniczne)

--- page 8 ---

- Zależne bezpośrednio od przedsiębiorstwa:
o Zasoby materialne
(kapitał, infrastruktura, technologia, )
o Zasoby niematerialne
(marka, reputacja, know-how, patenty,)
o Kapitał ludzki
(kwalifikacje pracowników, wiedza, kreatywność, motywacja)
o Innowacyjność
(zdolność do wdrażania nowych produktów, procesów i rozwiązań)
o Efektywność zarządzania
(styl przywództwa, struktura organizacyjna, systemy motywacyjne)
o Elastyczność i zdolność adaptacji
(szybkość reagowania na zmiany rynkowe)
 Determinanty zewnętrzne (egzogeniczne)
o Otoczenie makroekonomiczne
(inflacja, stopy procentowe, kursy walut)
o Uwarunkowania prawne i instytucjonalne
(prawo podatkowe, prawo pracy, stabilność regulacyjna)
o Dostęp do rynków i surowców
o Preferencje i zachowania konsumentów
o Globalizacja i integracja gospodarcza
 Determinanty przewagi konkurencyjnej
(Zgodnie z koncepcją M. Portera)
o Przewaga kosztowa
(niższe koszty produkcji i działalności)
o zasoby i kompetencje wewnętrzne
(wiedza, technologia,kapitał)

--- page 9 ---

o Zróżnicowanie (dyferencjacja)
(unikalność produktu/usługi, wysoka jakość obsługi marki plus
zaawansowane technologie plus know how i silne relacje z klientami)
o Koncentracja (nisza rynkowa)
(obsługa wąskiego segmentu rynku)
6.Omów działania nieetyczne w biznesie i przedstaw do nich
działania zapobiegawcze.
Działania nieetyczne w biznesie to takie zachowania, które naruszają zasady
moralne, uczciwość i rzetelność wobec interesariuszy, czyli klientów, pracowników,
dostawców czy społeczności lokalnej, mimo że czasem mogą formalnie mieścić się w
granicach prawa. Jak podkreślają autorzy literatury zarządczej, np. Griffin czy Stoner,
etyka w biznesie jest fundamentem trwałej przewagi konkurencyjnej, ponieważ
buduje zaufanie, reputację i lojalność klientów.
	
Przykłady działań nieetycznych
o Dyskryminacja i nierówne traktowanie ze względu na płeć, wiek,
pochodzenie czy niepełnosprawność.
o Mobbing i nękanie psychiczne prowadzi do spadku wydajności i rotacji
kadry.
o Nieprzestrzeganie zasad BHP naraża pracowników na ryzyko zdrowotne i
prawne konsekwencje dla firmy.
o Przymuszanie do nadgodzin lub pracy ponad siły skutkuje wypaleniem
zawodowym, zmniejszeniem motywacji i zaufania do firmy.
o Korupcja-przyjmowanie łapówek
o Oszustwa finansowe-fałszowanie dokumentów ukrywanie strat
o Nieuczciwa konkurencja-kradzież tajemnic handlowych prowadzenie
klientów w błąd.
o Prowadzenie klientów w błąd-fałszywa reklama ukrywanie wad produktu.
o Ignorowanie norm ekologicznych zanieczyszczanie środowiska, nadmierne
zużycie zasobów.

--- page 10 ---

 Działania zapobiegawcze
Firmy, które chcą chronić swoją reputację i zbudować zaufanie, wdrażają konkretne
mechanizmy i polityki etyczne:
▪ Kodeksy etyczne
Formalne dokumenty, które jasno definiują akceptowalne i nieakceptowalne
zachowania w organizacji. Mogą obejmować m.in. politykę antydyskryminacyjną,
zasady współpracy z klientami i partnerami, ochronę danych czy relacje z
otoczeniem, daje to pracownikom jasne wytyczne i pozwala łatwiej rozliczać
zachowania.
▪ Szkolenia z zakresu etyki
Regularne warsztaty i e-learning pokazujące konsekwencje działań nieetycznych np.
Utrata zaufania klientów, sankcje prawne czy utrata przewagi konkurencyjnej. Ułatwia
świadome podejmowanie decyzji które są zgodne z wartościami firmy.
▪ Sygnaliści
Bezpieczne i anonimowe kanały zgłaszania nieprawidłowości. Chronią pracowników
przed represjami, a firmę przed eskalacją problemów.
▪ System kontroli przejrzyste procedury.
▪ Sankcje
Podsumowanie
Działania nieetyczne niszczą reputację, relacje z interesariuszami i przewagę
konkurencyjną firmy. Ich eliminacja wymaga połączenia formalnych narzędzi
(kodeksy, systemy whistleblowing), edukacji (szkolenia), oraz strategicznego
podejścia. Skuteczna firma łączy te mechanizmy w jeden spójny system zarządzania
etycznego, co daje trwałą przewagę rynkową i zaufanie społeczne.

--- page 11 ---

7. Omów systemy informatyczne i narzędzia IT stosowane w
zarządzaniu różnymi obszarami przedsiębiorstwa. S
Zarządzanie we współczesnych organizacjach opiera się na sprawnym przepływie
informacji. Zgodnie z literaturą (np. J. Stoner), technologia w firmie dzieli się na
szerokie systemy informatyczne, które integrują całe działy, oraz konkretne
narzędzia IT, które wspierają poszczególne zadania. Celem ich stosowania jest
zwiększenie sprawności operacyjnej oraz dostarczenie managerom danych do
podejmowania trafnych decyzji.
Główne Systemy Informatyczne - W zarządzaniu wyróżniamy kluczowe systemy:
1. ERP (Enterprise Resource Planning): To kompleksowy system zarządzania
zasobami. Integruje on w jednej bazie danych obszary takie jak: finanse,
księgowość, kadry (ZZL) oraz magazyn. Dzięki niemu informacja
wprowadzona w jednym dziale jest natychmiast widoczna w innym.
2. CRM (Customer Relationship Management): System dedykowany
zarządzaniu relacjami z otoczeniem rynkowym. Służy do gromadzenia wiedzy
o klientach, historii kontaktów i transakcji, co pozwala na budowanie
długofalowej strategii lojalnościowej.
3. SCM (Supply Chain Management): System wspierający logistykę i łańcuch
dostaw. Pozwala na koordynację przepływu materiałów od dostawców do
firmy, optymalizując koszty magazynowania.
4. BI (Business Intelligence): Systemy analityczne dla wyższej kadry
managerskiej. Przetwarzają one dane z całego przedsiębiorstwa w czytelne
raporty i prognozy, wspierając funkcję planowania strategicznego.
5. Systemy HRM (Human Resource Management) to systemy informatyczne
wspierające zarządzanie zasobami ludzkimi w organizacji. Obejmują procesy
takie jak rekrutacja, rozwój pracowników, wynagradzanie oraz ewidencja
czasu pracy.

--- page 12 ---

Narzędzia IT (Konkretne rozwiązania) - Systemy te wykorzystują specyficzne
narzędzia IT, które usprawniają codzienne zarządzanie:
 ERP
o SAP – integracja procesów firmy (finanse, logistyka, HR, produkcja).
o Microsoft Dynamics 365 – ERP i CRM w chmurze, integracja
sprzedaży, finansów i HR
 CRM
o Salesforce – zarządzanie sprzedażą, marketingiem i relacjami z
klientami.
o HubSpot – CRM + automatyzacja marketingu i obsługi klienta.
 Zarządzanie projektami
o Asana – planowanie zadań i kontrola postępów.
o Trello – tablice zadań i organizacja pracy zespołu.
 Analiza danych (BI)
o Microsoft Power BI – raporty i wizualizacja danych.
o Tableau – analiza i prezentacja danych.
Komunikacja - Microsoft teams , zoom
8. Omów składniki otoczenia rynkowego przedsiębiorstwa i jego
rolę dla organizacji.
Zgodnie z klasyczną teorią zarządzania (m.in. R.W. Griffina), żadna organizacja nie
jest samowystarczalna. Jest ona systemem otwartym, co oznacza, że pozostaje w
ciągłej interakcji z otoczeniem. Otoczenie to ogół czynników, sił i podmiotów.Dzielimy
je na dwa podstawowe poziomy: makrootoczenie (dalsze) oraz mikrootoczenie
(bliższe).
Składniki otoczenia:

--- page 13 ---

 Makrootoczenie (Otoczenie dalsze): To siły, na które firma nie ma wpływu,
ale musi się do nich dostosować. Analizujemy je metodą PEST: o
Polityczno-prawne: Stabilność rządu, przepisy podatkowe i prawo pracy.
Wyznaczają one granice legalnego działania firmy.
o Ekonomiczne: Inflacja, kursy walut, PKB. Decydują o sile nabywczej
klientów i kosztach kredytów.
o Społeczno-kulturowe: Styl życia, demografia, wartości. Mówią nam,
jakie są preferencje konsumentów.
o Technologiczne: Szybkość innowacji, rozwój cyfryzacji. To one
stwarzają szanse na nowe produkty lub grożą wyparciem starych
rozwiązań.
 Mikrootoczenie (Otoczenie bliższe): To podmioty bezpośrednio związane z
firmą, na które możemy częściowo oddziaływać:
o Klienci: Odbiorcy naszych dóbr i usług; ich zadowolenie to fundament
zysku.
o Konkurenci: Firmy walczące o te same zasoby i klientów. Zmuszają
nas do ciągłego doskonalenia.
o Dostawcy: Partnerzy dostarczający surowce, energię czy technologie.
Od ich rzetelności zależy nasza ciągłość pracy.
o Pośrednicy: Firmy pomagające w sprzedaży, logistyce czy promocji.
 Rola otoczenia dla organizacji
Źródło informacji o rynku- Pozwala przedsiębiorstwu rozpoznać potrzeby klientów,
zachowania konkurencji i zmiany w trendach. Dzięki temu firma może dostosować
ofertę produktów, strategię marketingową i ceny.
Źródło szans i zagrożeń - Otoczenie pokazuje, gdzie pojawiają się nowe możliwości
(np. nowe rynki, technologie) oraz zagrożenia (np. regulacje, zmiany w konkurencji).
Firma reaguje na nie, żeby zwiększyć swoją konkurencyjność i minimalizować
ryzyko.

--- page 14 ---

Podstawa planowania strategicznego- Analiza otoczenia pozwala podejmować
lepsze decyzje dotyczące rozwoju firmy, inwestycji i alokacji zasobów. Umożliwia
przewidywanie zmian i adaptację strategii, np. zmiana produkcji w odpowiedzi na
nowe przepisy prawne lub trendy społeczne.
9. Wskaż grupy czynników kształtujących postępowanie
konsumentów na rynku i omów jedną z nich.
Zachowania konsumentów to proces podejmowania decyzji o tym, jak wydatkować
dostępne zasoby (czas, pieniądze, wysiłek) na produkty i usługi. Według Philippa
Kotlera, kluczowym zadaniem managera jest zrozumienie, jak bodźce zewnętrzne
zamieniają się w decyzję o zakupie. Te czynniki dzielimy na cztery główne grupy
Wskazanie grup czynników:
1. Czynniki Kulturowe: Najszersza grupa – kultura, subkultury i klasa
społeczna. To one mówią nam, co jest "właściwe" i pożądane w danej
społeczności.
2. Czynniki Społeczne: Grupy odniesienia (rodzina, znajomi), rola i status
społeczny. Często kupujemy to, co osoby, które podziwiamy.
3. Czynniki Osobiste: Wiek, zawód, sytuacja ekonomiczna, styl życia i
osobowość. Potrzeby 20-latka są inne niż 60-latka.
4. Czynniki Psychologiczne: Motywacja, percepcja (sposób patrzenia na
markę), uczenie się oraz przekonania i postawy.
Omówienie wybranej grupy – Czynniki Psychologiczne
Chciałabym bliżej omówić czynniki psychologiczne, ponieważ to one bezpośrednio
sterują decyzją w momencie zakupu. Składają się na nie cztery elementy:
● Motywacja: To siła, która pcha nas do działania. Tutaj warto wspomnieć o
Hierarchii potrzeb Maslowa. Konsument najpierw zaspokaja potrzeby
fizjologiczne i bezpieczeństwa, a dopiero potem myśli o prestiżu czy

--- page 15 ---

samorealizacji. Manager musi wiedzieć, na jakim poziomie potrzeb operuje
jego produkt.
● Percepcja: Każdy z nas inaczej widzi ten sam produkt. Jeden klient uzna
cenę za 'atrakcyjną', inny za 'podejrzanie niską'. To proces selekcji i
interpretacji bodźców.
● Uczenie się: Nasze zachowania wynikają z doświadczeń. Jeśli klient raz kupi
produkt i będzie zadowolony, 'nauczy się', że tej marce warto ufać (lojalność).
● Przekonania i postawy: To utrwalone opinie na temat produktów. Bardzo
trudno je zmienić, dlatego firmy starają się dopasować do istniejących postaw,
zamiast z nimi walczyć.
Podsumowanie "Podsumowując, jak zauważa Griffin, manager, który rozumie te
czynniki, może lepiej segmentować rynek i tworzyć skuteczniejsze strategie
marketingowe. Znajomość postępowania konsumentów pozwala firmie nie tylko
sprzedawać, ale przede wszystkim dostarczać wartość, której klient faktycznie
potrzebuje.
Lub Podsumowując,
literatura zarządzania
wskazuje, że analiza
zachowań konsumentów
umożliwia firmom lepsze
dopasowanie oferty do
potrzeb rynku
10. Omów składniki i zastosowanie analizy SWOT i TOWS.
Analiza SWOT/TOWS to fundament planowania strategicznego. Pozwala ona na
zestawienie potencjału wewnętrznego firmy z sytuacją w jej otoczeniu. Według R.W.
Griffina, jest to punkt wyjścia do wyboru strategii rozwoju organizacji.
Analiza opiera się na czterech grupach czynników:
 Czynniki Wewnętrzne (Zależne od firmy):

--- page 16 ---

o S (Strengths) – Mocne strony: To wszystko, co organizacja robi
dobrze. Mogą to być: unikalne technologie, wysokie kwalifikacje
pracowników, silna marka czy stabilna sytuacja finansowa.
o W (Weaknesses) – Słabe strony: To braki i ograniczenia, które
utrudniają osiąganie celów. Przykłady: przestarzały park maszynowy,
wysoka rotacja pracowników, brak płynności finansowej lub słaba sieć
dystrybucji.
 Czynniki Zewnętrzne (Pochodzące z otoczenia):
o O (Opportunities) – Szanse: Zjawiska w makro- i mikrootoczeniu,
które firma może wykorzystać do rozwoju. Przykłady: osłabienie
konkurencji, nowe dotacje unijne, zmiany w prawie sprzyjające branży
czy nowe trendy konsumenckie.
o T (Threats) – Zagrożenia: Bariery i niebezpieczeństwa poza firmą.
Przykłady: wzrost cen surowców, agresywna konkurencja, inflacja czy
zmiana preferencji klientów, która czyni nasz produkt zbędnym.
 Zastosowanie
● Logika SWOT (Od wewnątrz do zewnątrz)- Sprawdzamy, jak nasze
mocne strony mogą pomóc nam wykorzystać szanse rynkowe.
● Logika TOWS (Od zewnątrz do wewnątrz): TOWS robisz odwrotnie.
Najpierw patrzysz na rynek i zagrożenia, a potem sprawdzasz, czy
Twoja firma ma „broń”, żeby sobie z tym poradzić. To jest analiza
bardziej obronna i reakcyjna. Sprawdzamy, jak zagrożenia z rynku
mogą uderzyć w nasze słabe strony i jak musimy się przed tym bronić.
 Wynik analizy – 4 Strategie Strategiczne

--- page 17 ---

Zastosowaniem analizy SWOT/TOWS jest wybór odpowiedniej strategii działania.To
pozwala managerowi nie błądzić po omacku, tylko dopasować ruchy firmy do tego,
co dzieje się na rynku.
1. Strategia Agresywna (Maxi-Maxi): Wykorzystujemy mocne strony do
maksymalnego wykorzystania szans. To czas na szybki wzrost i inwestycje.
2. Strategia Konserwatywna (Maxi-Mini): Mamy mocne strony, ale rynek jest
groźny. Firma używa swojego potencjału, aby przetrwać trudny czas i
"przeczekać" zagrożenia.
3. Strategia Konkurencyjna (Mini-Maxi): Mamy słabe strony, ale na rynku są
wielkie szanse. Firma musi szybko naprawić swoje błędy (np. wziąć kredyt,
zatrudnić ekspertów), aby nie przegapić okazji.
4. Strategia Defensywna (Mini-Mini): Firma jest słaba w groźnym otoczeniu. To
sytuacja kryzysowa. Zastosowanie: Walka o przetrwanie, fuzja z inną firmą lub
likwidacja części działalności.
Analiza SWOT/TOWS jest narzędziem uniwersalnym. Jej głównym zastosowaniem w
zarządzaniu jest podjęcie decyzji o alokacji zasobów – czyli wskazanie, gdzie
warto inwestować pieniądze i czas, a skąd należy się wycofać, by zminimalizować
ryzyko strat.
11. Omów jedną definicję marketingu tradycyjnego i jedną
współczesnego, podaj przykłady.
 Marketing Tradycyjny
Definicja: Według klasycznego ujęcia (np. Ph. Kotlera z wcześniejszych lat),
marketing tradycyjny to proces planowania i realizacji koncepcji cen, promocji i
dystrybucji towarów w celu doprowadzenia do wymiany. Skupia się on przede
wszystkim na produkcie i na tym, jak go sprzedać jak największej liczbie osób.

--- page 18 ---

Kluczowe cechy:
▪ Komunikat jednostronny (firma mówi do klienta przez TV, radio, ulotki).
▪ Cel: Sprzedaż tu i teraz (transakcja).
▪ Narzędzie: Masowość (docieranie do wszystkich naraz).
Przykład: Wielka kampania reklamowa nowej margaryny w telewizji oraz gazetkach
promocyjnych w supermarketach. Firma produkuje ogromną ilość towaru i za
pomocą agresywnej reklamy oraz niskiej ceny stara się przekonać każdego
przechodnia do zakupu, nie pytając go wcześniej o zdanie.
 Marketing Współczesny
Definicja: Współczesna definicja (również według nowszych wydań Kotlera i Kellera)
określa marketing jako naukę i sztukę badania, tworzenia i dostarczania wartości,
aby zaspokoić potrzeby docelowego rynku z korzyścią dla klienta. Skupia się on na
kliencie i budowaniu z nim trwałej relacji.
Kluczowe cechy:
▪ Komunikat dwustronny (dialog z klientem w mediach społecznościowych).
▪ Cel: Budowanie lojalności i satysfakcji klienta (relacja).
▪ Narzędzie: Personalizacja (oferta dopasowana do konkretnej osoby).
Przykład: Aplikacja mobilna sieci kawiarni (np. Starbucks). System analizuje, że
zazwyczaj kupujesz kawę karmelową we wtorki rano. W poniedziałek wieczorem
wysyła Ci powiadomienie: „Cześć [Twoje Imię], jutro Twoja ulubiona kawa 20%
taniej!”. Firma nie tylko sprzedaje, ale dba o Twoją wygodę i pokazuje, że Cię zna.
Pods: Z punktu widzenia zarządzania, różnica polega na zmianie orientacji. W
marketingu tradycyjnym rządzili produkcja i sprzedawcy (orientacja na produkt). W
marketingu współczesnym rządzi klient (orientacja na klienta). Obecnie nie

--- page 19 ---

szukamy klientów dla naszych produktów, ale szukamy produktów dla naszych
klientów.
Jak to zapamiętać?
▪ Tradycyjny = „Kup pan cegłę” (Agresywna sprzedaż tego, co mamy w
magazynie).
▪ Współczesny = „Powiedz mi, czego
potrzebujesz, a ja to dla Ciebie
stworzę” (Dostarczanie wartości).
Marketing tradycyjny to podejście skupione na
transakcji i produkcie, gdzie manager zarządza
za pomocą suwaków 4P (produktu, ceny,
dystrybucji i promocji), czego przykładem jest
masowa reklama telewizyjna margaryny
kierowana do każdego odbiorcy.
W przeciwieństwie do niego, marketing współczesny opiera się na budowaniu
trwałych relacji i dostarczaniu wartości dopasowanej do konkretnego klienta, a nie
tylko na samej sprzedaży towaru.
12. Wymień metody i techniki organizatorskie. Scharakteryzuj jedną
wybraną. (albo ta albo ta, spy kogoś)
Metody organizatorskie porządkują pracę i procesy w organizacji, a techniki to
konkretne sposoby realizacji tych metod

--- page 20 ---

 Podstawowe metody organizatorskie:
o Metody sieciowe: Służą do planowania i kontroli złożonych projektów,
pozwalają na identyfikację ścieżki krytycznej.
o Analiza wartości (Value Analysis): Badanie funkcji poszczególnych
elementów struktury lub produktu w celu obniżenia kosztów przy
zachowaniu jakości.
o Badanie metod pracy: Systematyczne rejestrowanie i krytyczna
analiza sposobów wykonywania czynności w celu usprawnienia pracy.
o Wartościowanie pracy: Obiektywna ocena stanowisk pracy w celu
ustalenia hierarchii i sprawiedliwego systemu wynagrodzeń.
 Techniki organizacji czasu i zadań:
o Matryca Eisenhowera: Segregowanie zadań według ważności i
pilności.
o Metoda Pomodoro: Praca w skupieniu przez 25 minut, a następnie
krótka przerwa.
o Metoda ABC: Priorytetyzacja zadań (A - kluczowe, B - ważne, C -
mniej istotne).
o Bloki czasowe (Time Blocking): Planowanie konkretnych bloków czasu
na określone zadania.
Metoda organizatorska – Badanie metod pracy
▪ Polega na obserwacji, rejestrowaniu i analizowaniu czynności
wykonywanych przez pracowników.
▪ Celem jest usprawnienie procesów, eliminacja zbędnych działań i
zwiększenie wydajności pracy.
▪ Może obejmować np. skracanie czasu wykonywania zadania lub zmianę
kolejności czynności.
Przykład:

--- page 21 ---

• W restauracji obserwujesz proces przygotowywania sałatki → analizujesz ruchy
kucharza → wprowadzasz usprawnienia, np. składniki bliżej stanowiska, żeby
oszczędzić czas.
Technika organizatorska – Matryca Eisenhowerato technika priorytetyzacji w
czasie
Charakterystyka:
▪ Pomaga priorytetyzować zadania: ważne/pilne, ważne/niepilne,
pilne/nieważne, niepilne/nieważne.
▪ Ułatwia efektywne wykorzystanie czasu i unikanie przestojów.
Przykład:
▪ Pilny raport → robisz od razu
▪ Długoterminowy projekt → planujesz w kalendarzu
▪ Zadania mało istotne → delegujesz lub eliminujesz
13. Z jakich elementów składa się plan marketingowy? Krótko
omów poszczególne elementy i ich cel.spy
1. Streszczenie menedżerskie (Executive Summary)
o Opis: Zwarty przegląd całego dokumentu, zawierający kluczowe
wnioski i rekomendacje.
o Cel: Umożliwienie kadrze zarządzającej (CEO/Zarządowi)
błyskawicznego zrozumienia istoty planu i podjęcia decyzji o jego
akceptacji bez czytania całości.
2. Analiza sytuacji (w tym SWOT)
o Opis: Szczegółowy opis obecnego położenia firmy na rynku, w tym
analiza konkurencji i otoczenia makroekonomicznego.

--- page 22 ---

o Szczegół: Wykorzystuje się tu Analizę SWOT, która zestawia
wewnętrzne atuty firmy z zewnętrznymi szansami rynkowymi.
o Cel: Zidentyfikowanie przewag konkurencyjnych oraz ryzyk, które mogą
wpłynąć na realizację planu.
3. Cele marketingowe (zgodnie ze SMART)
o Opis: Wyznaczenie punktów docelowych, które firma chce osiągnąć w
danym czasie.
o Szczegół: Muszą być SMART (Konkretne, Mierzalne, Ambitne, Realne,
Terminowe).
o Cel: Nadanie kierunku działaniom i stworzenie bazy do późniejszego
rozliczenia zespołu z efektów (np. wzrost udziału w rynku o 5% w rok).
4. Strategia marketingowa (STP)
o Opis: Wybór sposobu walki o klienta. Składa się z Segmentacji (podział
rynku), Targetowania (wybór grupy) i Pozycjonowania (wizerunek
marki).
o Cel: Skupienie ograniczonych zasobów firmy na tych grupach klientów,
które przyniosą największy zysk.
5. Programy działań (Marketing-mix 4P/5P)
o Opis: Operacyjne narzędzia marketingu: Produkt (cechy), Cena
(poziom cen i rabaty), Dystrybucja (miejsce sprzedaży) i Promocja
(komunikacja).
o Szczegół: Według Armstronga, kluczowe jest tu również 5P – People
(Ludzie), czyli jakość obsługi klienta.
o Cel: Praktyczna realizacja strategii – dostarczenie odpowiedniego
produktu we właściwe miejsce i czas.
6. Budżet marketingowy
o Opis: Zestawienie wszystkich planowanych wydatków oraz
przewidywanych przychodów.
o Cel: Kontrola finansowa i ocena rentowności – manager musi
wiedzieć, czy planowana kampania ma szansę się zwrócić (ROI).
7. Kontrola i monitoring (wskaźniki KPI)

--- page 23 ---

o Opis: Wyznaczenie mierników sukcesu (Key Performance Indicators)
oraz metod ich sprawdzania.
o Cel: System "wczesnego ostrzegania" – pozwala managerowi szybko
skorygować działania, jeśli wyniki sprzedażowe odbiegają od założeń
planu.
8. Harmonogram który określa kiedy i w jakiej kolejności będą
realizowane wybrane działania.
SWOT – Sprawdzenie formy firmy
To narzędzie służy do tego, żebyś wiedziała, co się dzieje w firmie i wokół niej.
Dzięki temu nie działasz po omacku.
● S (Mocne strony): To, co u nas działa super (np. mamy najlepszego
kucharza w mieście).
● W (Słabe strony): To, co kuleje (np. mamy stary wystrój lokalu).
● O (Szanse): Coś fajnego, co dzieje się na zewnątrz (np. obok otwiera się
biurowiec z tysiącem głodnych ludzi).
● T (Zagrożenia): Coś złego z zewnątrz (np. ceny prądu idą mocno w górę).
Po co to managerowi? Żeby wiedzieć, jakimi atutami (S) atakować okazje (O) i jak
pilnować słabych punktów (W) przed problemami (T).
SMART – Dobrze sformułowane zadanie
To sposób na to, żebyś wiedziała, jak wydać polecenie, żeby było jasne i wykonane
na czas.
● S (Konkretny): Nie mów „sprzedawajcie więcej”, powiedz „sprzedajcie więcej
kawy latte”.
● M (Mierzalny): Dodaj liczbę – „o 50 sztuk więcej niż wczoraj”.
● A (Osiągalny): Nie daj celu z kosmosu – musi być realny do zrobienia.
● R (Ważny): Musi mieć sens dla firmy (nie każesz im liczyć gołębi na dachu).
● T (Na czas): Musi mieć termin – „zróbcie to do najbliższego piątku

--- page 24 ---

● SWOT to zbadanie terenu (czy mamy siły i jakie są przeszkody). SMART to
wyznaczenie konkretnego celu, żeby nikt nie musiał zgadywać, o co Ci chodzi.
14. Wymień podstawowe strategie cenowe oraz czynniki je
determinujące.
Strategia cenowa Krótka charakterystyka 	Determinanty
Strategia cen
niskich
Oferowanie cen niższych niż
konkurencja w celu zdobycia
rynku i wolumenu sprzedaży.
Niski koszt produkcji, duża
wrażliwość popytu na cenę, silna
konkurencja.
Strategia cen
neutralnych
Ustalanie cen na poziomie
zbliżonym do średniej
rynkowej, konkurowanie
innymi atutami.
Średnie koszty, stabilny popyt,
umiarkowana konkurencja.

--- page 25 ---

Strategia cenowa Krótka charakterystyka 	Determinanty
Strategia cen
wysokich
Ustalanie wysokich cen
podkreślających
ekskluzywność, jakość i
prestiż.
Wysoka jakość, prestiż marki,
niska elastyczność popytu.
Strategia zbierania
śmietanki
Wprowadzenie produktu po
wysokiej cenie, a następnie
stopniowe jej obniżanie.
Innowacyjność produktu,
ograniczona konkurencja,
wysoka wartość postrzegana,
krótki cykl życia produktu.
Strategia penetracji
rynku
Wprowadzenie produktu po
bardzo niskiej cenie w celu
szybkiego zdobycia dużego
udziału w rynku.
Wysoki potencjał popytu, silna
konkurencja, elastyczny popyt.
Strategia eliminacji
konkurentów
Agresywne obniżanie cen
(często poniżej kosztów) w
celu wyparcia rywali z rynku.
Siła finansowa, przewaga
technologiczna, dostęp do
kanałów dystrybucji, reputacja
marki.
Czynniki determinujące poziom ceny:
1) Koszty
Wyznaczają dolną granicę ceny – firma musi pokryć koszty i osiągnąć
rentowność.
2) Popyt / wartość dla klienta
Określają górną granicę ceny – klient zapłaci tylko tyle, ile uważa za
uzasadnione.
3) Konkurencja
Ceny muszą być odniesione do cen produktów konkurencyjnych i substytutów.

--- page 26 ---

4) Cele przedsiębiorstwa
Cena zależy od tego, czy celem jest szybki zysk, zdobycie rynku, przetrwanie
czy budowa wizerunku.
5) Regulacja prawne, warunki ekonomiczne, cykl życia produktu i
pozycjonowanie marki i jakość produktu
15. Omów cykl życia produktu na rynku i działania przedsiębiorstwa
w każdej z faz cyklu.
CYKL ŻYCIA PRODUKTU – 4 GŁÓWNE FAZY
Faza wprowadzenia (Introduction)
To moment debiutu produktu. Sprzedaż rośnie powoli, a zyski są ujemne ze względu
na ogromne koszty promocji i dystrybucji.
 Działania przedsiębiorstwa:
o Informowanie klientów o nowym produkcie.
o Wybór strategii cenowej: zbieranie śmietanki (wysoka cena) lub
penetracja (niska cena).
o Budowanie sieci dystrybucji.
Faza wzrostu (Growth)
Rynek akceptuje produkt, a sprzedaż gwałtownie rośnie. Pojawiają się pierwsi
naśladowcy i konkurenci.
 Działania przedsiębiorstwa:
o Poprawa jakości produktu i dodawanie nowych cech.
o Wejście w nowe segmenty rynku i kanały dystrybucji.
o Zmiana reklamy z informacyjnej na nakłaniającą (budowanie preferencji
marki).

--- page 27 ---

Faza dojrzałości (Maturity)
To najdłuższa faza. Sprzedaż osiąga szczyt, ale tempo wzrostu spada. Rynek jest
nasycony, a konkurencja cenowa staje się bardzo ostra.
 Działania przedsiębiorstwa:
o Modyfikacja rynku: szukanie nowych użytkowników lub zwiększanie
częstotliwości użycia produktu.
o Modyfikacja produktu: zmiana wyglądu, opakowania lub
funkcjotnalności.
Często stosuje się promocje cenowe i programy lojalnościowe, aby utrzymać
klientów
Faza spadku (Decline)
Sprzedaż i zyski drastycznie spadają z powodu postępu technicznego lub zmiany
gustów klientów.
 Działania przedsiębiorstwa:
o Strategia "wyciskania" (harvesting): ograniczanie kosztów do
minimum przy jednoczesnym utrzymywaniu sprzedaży.
o Wycofanie produktu: całkowite zaprzestanie produkcji i sprzedaży.
Podsumowanie : Twoim celem jako managera jest jak najdłuższe utrzymanie
produktu w fazie dojrzałości, ponieważ to wtedy firma generuje największe
nadwyżki gotówki, które można zainwestować w nowe produkty

--- page 28 ---

16. Wymień narzędzia zintegrowanej komunikacji marketingowej.
Zintegrowana komunikacja marketingowa polega na spójnym i skoordynowanym
wykorzystaniu różnych narzędzi komunikacji, tak aby marka przekazywała jedno,
konsekwentne przesłanie we wszystkich punktach kontaktu z klientem.
Podstawowe (klasyczne) narzędzia IMC:
▪ Reklama – tradycyjna i digital (telewizja, radio, prasa, outdoor, Google Ads,
reklamy w social media).
o Cel: budowanie świadomości marki i jej wizerunku.
▪ Public Relations (PR) – relacje z mediami i opinią publiczną, artykuły,
wydarzenia, sponsoring.
o Cel: budowanie zaufania i reputacji firmy.
▪ Promocja sprzedaży – rabaty, kupony, akcje specjalne, oferty limitowane,
programy lojalnościowe.
o Cel: krótkoterminowe zwiększenie sprzedaży.
▪ Marketing bezpośredni – e-mail marketing, SMS, mailing, automatyzacja
marketingu, systemy CRM.
o Cel: bezpośrednia, spersonalizowana komunikacja z klientem.

--- page 29 ---

▪ Sprzedaż osobista – handlowcy, konsultanci, doradcy klienta, opiekunowie
klientów B2B.
o Cel: budowanie relacji i dopasowanie oferty do potrzeb klienta.
Współczesne uzupełnienie IMC (digital marketing):
▪ Content marketing – blogi, wideo, webinary, podcasty, poradniki.
o Cel: edukowanie klienta i budowanie eksperckiego wizerunku marki.
▪ Media społecznościowe i influencer marketing – Facebook, Instagram,
TikTok, LinkedIn, YouTube, współpraca z influencerami.
o Cel: dialog z odbiorcami i zaangażowanie społeczności.
17.Omów klasyfikację kosztów w rachunkowości.
Klasyfikacja według zmienności
To podstawowy podział wykorzystywany przy analizie progu rentowności (BEP).
 Koszty stałe: Pozostają na niezmienionym poziomie niezależnie od wielkości
produkcji (np. czynsz za halę, amortyzacja maszyn, wynagrodzenia
administracji).
 Koszty zmienne: Zmieniają się proporcjonalnie do wielkości produkcji (np.
surowce, energia zużyta w procesie technologicznym, wynagrodzenia
akordowe).
Klasyfikacja według sposobu przypisania do produktu
Ten podział jest niezbędny do obliczenia kosztu wytworzenia konkretnej sztuki
towaru.

--- page 30 ---

 Koszty bezpośrednie: Można je precyzyjnie przypisać do konkretnego
produktu na podstawie dokumentów (np. materiały bezpośrednie, robocizna
bezpośrednia).
 Koszty pośrednie (ogólne): Dotyczą wielu produktów jednocześnie lub
funkcjonowania całego zakładu; rozlicza się je za pomocą tzw. Kluczy
rozliczeniowych (np. oświetlenie hali, koszty zarządu, ubezpieczenie
budynku).
Klasyfikacja według funkcji (Układ funkcjonalny)
Pokazuje, w jakich obszarach działalności firmy powstają wydatki.
 Koszty wytworzenia: Związane bezpośrednio z produkcją wyrobów.
 Koszty sprzedaży: Nakłady na reklamę, transport do klienta, opakowania.
 Koszty ogólnego zarządu: Związane z funkcjonowaniem administracji i
utrzymaniem dyrekcji.
Klasyfikacja według rodzaju (Układ rodzajowy)
1) Jest to standardowy podział księgowy, który odpowiada na pytanie: "na co
wydaliśmy pieniądze?".
2) Amortyzacja- oznacza, że firma nie wrzucę całej ceny maszyny czy
samochodów koszty na raz tylko rozlicza się stopniowo przez kilka lat.
3) Zużycie materiałów i energii.
4) Usługi obce.
5) Podatki i opłaty.
6) Wynagrodzenia.
7) Ubezpieczenia społeczne i inne świadczenia.
18. Opisz, co powinien zawierać biznes plan, omów jego funkcje i
strukturę.

--- page 31 ---

Biznesplan to dokument opisujący koncepcję przedsięwzięcia, sposób jego realizacji
oraz ocenę opłacalności.
1) Streszczenie
Pierwsza część biznesplanu (pisana na końcu). Pełni funkcję „wizytówki”
dokumentu. Zawiera:
▪ cel przygotowania biznesplanu,
▪ wysokość posiadanych środków finansowych,
▪ opis oferowanych produktów i usług,
▪ opis umiejętności kadry kierowniczej,
▪ najważniejsze dane finansowe.
2) Charakterystyka przedsiębiorstwa
Krótki opis firmy obejmujący:
▪ nazwę i formę prawną przedsiębiorstwa,
▪ dane adresowe,
▪ datę rozpoczęcia działalności,
▪ opis właścicieli,
▪ historię, cel i misję firmy,
▪ dotychczasowe osiągnięcia (nagrody, certyfikaty),
▪ posiadane zasoby.

--- page 32 ---

3) Opis produktu lub usługi
Opis głównego przedmiotu działalności:
▪ charakterystyka produktu/usługi,
▪ proces produkcji i sprzedaży,
▪ zalety i wady,
▪ cechy wyróżniające na tle konkurencji,
▪ patenty i prawa autorskie (jeśli występują),
▪ rentowność,
▪ zgodność z normami,
▪ stadium życia produktu,
▪ plany modernizacji.
4) Otoczenie wewnętrzne (pracownicy)
Dotyczy zasobów ludzkich:
▪ kwalifikacje kadry kierowniczej i pracowników,
▪ struktura organizacyjna,
▪ system komunikacji,
▪ podział obowiązków,
▪ polityka płacowa, zatrudnienia i szkoleń,

--- page 33 ---

▪ system kontroli i monitoringu decyzji.
5) Otoczenie zewnętrzne (rynek i konkurencja)
Analiza warunków rynkowych:
▪ pozycja firmy na rynku,
▪ analiza branży,
▪ charakterystyka konkurencji,
▪ analiza SWOT,
▪ charakterystyka klientów,
▪ bariery wejścia i wyjścia z rynku.
6) Marketing i sprzedaż
Opis sposobu osiągania przychodów – koncepcja 4P:
▪ Product – produkt/usługa,
▪ Price – polityka cenowa, rabaty, ceny konkurencji,
▪ Place – kanały dystrybucji, formy sprzedaży i płatności,
▪ Promotion – reklama, promocja, PR, budżet marketingowy.
7) Plany i harmonogram działań
▪ harmonogram realizacji działań,
▪ plan organizacyjny, marketingowy i finansowy,
▪ prognozy na minimum 5 lat działalności.

--- page 34 ---

8) Analiza finansowa
Najważniejsza część biznesplanu, obejmuje:
▪ bilans,
▪ rachunek zysków i strat,
▪ cash flow,
▪ próg rentowności,
▪ źródła finansowania,
▪ analizę rentowności, płynności i zadłużenia,
▪ archiwalne dane finansowe (jeśli istnieją).
9) Załączniki
Dodatkowe dokumenty:
▪ struktura organizacyjna,
▪ sprawozdania finansowe,
▪ specyfikacje produktów,
▪ wyniki badań rynku,
▪ kopie umów z partnerami.
Funkcje biznesplanu
Według literatury biznesplan pełni trzy kluczowe funkcje:

--- page 35 ---

o Funkcja wewnętrzna (Planistyczna): Pozwala przedsiębiorcy na
uporządkowanie koncepcji biznesowej, wyznaczenie celów oraz identyfikację
potrzebnych zasobów. Służy jako narzędzie kontroli realizacji zadań w czasie.
o Funkcja zewnętrzna (Informacyjno-komunikacyjna): Jest niezbędny do
pozyskania kapitału z zewnątrz (np. kredyt bankowy, wejście inwestora).
Uwiarygadnia przedsięwzięcie w oczach partnerów biznesowych.
o Funkcja decyzyjna: Pomaga ocenić opłacalność projektu i podjąć ostateczną
decyzję o jego uruchomieniu lub zaniechaniu w oparciu o analizę ryzyka.
Co powinien zawierać skuteczny biznesplan?
Aby dokument był wyczerpujący i prawdziwy w oczach zarządu lub banku, musi
posiadać cechy wymieniane przez P. Druckera oraz R.W. Griffina:
o Realizm: Dane finansowe nie mogą być wyssane z palca; muszą opierać się
na rzetelnych badaniach rynkowych.
o Kompletność: Musi uwzględniać nie tylko optymistyczne scenariusze, ale i
potencjalne problemy (analiza ryzyka).
o Mierzalność celów: Zgodnie z zasadą SMART, cele w biznesplanie muszą być
konkretne i określone w czasie.
19. Omów różnice między wizją, misją i strategią organizacji. Podaj
przykłady misji i wizji
Cecha 	Wizja 	Misja 	Strategia
Pytanie Kim chcemy być w
przyszłości?
Po co istniejemy i co
robimy teraz?
Jak osiągniemy nasze
cele?
Perspektyw
a
Daleka przyszłość
(marzenie).
Teraźniejszość i bliska
przyszłość.
Konkretne działania i
kroki.

--- page 36 ---

Cecha 	Wizja 	Misja 	Strategia
Odbiorca Głównie pracownicy i
liderzy.
Klienci, społeczeństwo,
rynek.
Kadra zarządzająca i
operacyjna.
1) Wizja (Vision)
Wizja to ambitny obraz przyszłości firmy. To „gwiazda polarna”, która pokazuje, gdzie
organizacja chce się znajdować za 10–20 lat. Powinna być inspirująca i krótka.
▪ Przykład (Disney): „Uszczęśliwiać ludzi”.
▪ Przykład (Microsoft - dawniej): „Komputer na każdym biurku i w każdym
domu”.
2) Misja (Mission)
Misja określa sens istnienia firmy, jej unikalność i to, jaką wartość dostarcza klientom.
Odpowiada na pytanie: „W jakim biznesie jesteśmy?”.
▪ Przykład (Google): „Uporządkowanie światowych zasobów informacji, tak by
stały się powszechnie dostępne i użyteczne”.
▪ Przykład (IKEA): „Tworzenie lepszego codziennego życia dla wielu ludzi
poprzez oferowanie szerokiego asortymentu funkcjonalnych i dobrze
zaprojektowanych artykułów wyposażenia domu w cenach tak niskich, by jak
najwięcej osób mogło sobie na nie pozwolić”.
3) Strategia (Strategy)
Strategia to kompleksowy plan gry. Według M. Portera, strategia polega na wyborze
zestawu działań, które pozwolą uzyskać przewagę konkurencyjną. Podczas gdy

--- page 37 ---

misja mówi „co robimy”, strategia mówi „jakimi konkretnymi metodami pokonamy
konkurencję”.
▪ Przykład: Strategia lidera kosztowego (oferowanie najniższych cen na rynku
dzięki automatyzacji produkcji).
PODSUMOWANIE NA EGZAMIN:
• Wizja to obraz przyszłości (marzenie).
• Misja to powód istnienia (tożsamość).
• Strategia to droga do celu (plan działania)
20. Omów istotę i rodzaje strategii przedsiębiorstwa.
❖ Istota strategii przedsiębiorstwa
Strategia przedsiębiorstwa to długookresowa koncepcja działania, która określa:
o cele organizacji,
o kierunki rozwoju,
o sposoby alokacji zasobów,
o metody budowania i utrzymywania przewagi konkurencyjnej w zmiennym
i konkurencyjnym otoczeniu.
Istota strategii sprowadza się do budowania twojej przewagi konkurencyjnej
wyboru rynku docelowych rozwoju produktów i zapewnia rentowności.
Rodzaje strategii (Klasyfikacje)

--- page 38 ---

1) Strategie na poziomie korporacji (ogólne)- Określają, w jakich branżach firma
chce działać.
● Strategia wzrostu: zakłada ekspansję, zwiększanie skali produkcji lub
wchodzenie na nowe rynki.
● Strategia stabilizacji: koncentruje się na utrzymaniu obecnej pozycji
rynkowej i optymalizacji działań.
● Strategia defensywna (naprawcza): stosowana w sytuacjach
kryzysowych; polega na cięciu kosztów, redukcji personelu lub wycofaniu
się z nierentownych rynków.
2) Strategie konkurencji (według M. Portera)
Są to najbardziej popularne rodzaje strategii określające, jak walczyć z rywalami w
danej branży:
● Strategia lidera kosztowego: dążenie do posiadania najniższych kosztów
produkcji i działalności, co pozwala oferować niskie ceny.
● Strategia zróżnicowania (dyferencjacji): budowanie unikalności produktu
(jakość, marka, technologia), za którą klienci są gotowi zapłacić więcej.
● Strategia koncentracji (niszy): skupienie się na obsłudze bardzo
wąskiego segmentu rynku lub grupy klientów.
3) Strategie funkcjonalne
Wspierają realizację strategii ogólnej w konkretnych działach firmy.
● Strategia marketingowa: określa sposób kształtowania produktu, ceny i
promocji.
● Strategia finansowa: dotyczy pozyskiwania kapitału i zarządzania
płynnością.
● Strategia personalna (ZZL): skupia się na pozyskiwaniu i motywowaniu
pracowników.
● Strategia operacyjna: dotyczy procesów wytwórczych i logistyki.
4) Strategie według kierunków rozwoju (Macierz Ansoffa)

--- page 39 ---

● Penetracja rynku: zwiększanie sprzedaży obecnych produktów na
obecnych rynkach.
● Rozwój rynku: wprowadzanie obecnych produktów na nowe rynki (np.
eksport).
● Rozwój produktu: tworzenie nowych produktów dla obecnych klientów.
● Dywersyfikacja: wchodzenie z nowymi produktami na zupełnie nowe
rynki.
21. Wyjaśnij znaczenie i istotę zarządzania projektami we
współczesnych organizacjach.
Zarządzanie projektami to proces planowania, organizowania, przewodzenia,
realizacji i kontroli zasobów organizacji w celu osiągnięcia konkretnego, unikalnego i
ograniczonego w czasie celu. Projekty różnią się od działalności rutynowej tym, że są
jednorazowe, mają jasno określony początek i koniec oraz prowadzą do powstania
nowej wartości (np. produktu, usługi, zmiany organizacyjnej).
Istota zarządzania projektami
Kluczową istotą zarządzania projektami jest realizacja złożonych zadań przy
zachowaniu równowagi między elementami tzw. trójkąta ograniczeń, który
obejmuje:
1. Zakres – co ma zostać wykonane,
2. Czas – termin realizacji projektu,
3. Koszt – dostępny budżet.
Zmiana jednego z tych elementów wpływa na pozostałe, dlatego zarządzanie
projektem polega na ich ciągłej koordynacji. Istotą jest także:
▪ koordynacja pracy zespołów interdyscyplinarnych,
▪ efektywne wykorzystanie zasobów,
▪ kontrola ryzyka, kosztów i terminów.

--- page 40 ---

Znaczenie zarządzania projektami we współczesnych organizacjach
Zarządzanie projektami jest dziś niezbędne, ponieważ:
▪ umożliwia szybkie wdrażanie innowacji w warunkach dynamicznego
postępu technologicznego,
▪ zwiększa efektywność wykorzystania zasobów ludzkich i finansowych,
▪ zapewnia elastyczność działania i szybką reakcję na zmiany rynkowe,
▪ pozwala na identyfikację i ograniczanie ryzyka,
▪ wspiera realizację strategii organizacji,
▪ przyczynia się do budowania przewagi konkurencyjnej przedsiębiorstwa
Metodyki zarządzania projektami
Waterfall (podejście kaskadowe)
Waterfall to metodyka tradycyjna, w której projekt realizowany jest etap po etapie.
Każda faza musi zostać zakończona przed rozpoczęciem kolejnej. Charakteryzuje
się:
o liniowym przebiegiem,
o sztywnym planem,
o małą elastycznością zmian. Stosowana jest głównie w projektach o jasno
określonych wymaganiach.
Agile (podejście zwinne)
Agile to podejście oparte na elastyczności i adaptacji do zmian. Zakłada realizację
projektu w krótkich iteracjach (sprintach), regularną współpracę zespołu oraz

--- page 41 ---

częste dostarczanie wartości dla klienta. Agile jest filozofią pracy, a nie jedną
konkretną metodą.
Scrum
Scrum to jedna z najpopularniejszych metodyk zwinnych działających w ramach
Agile. Opiera się na:
o pracy w sprintach (1–4 tygodnie),
o jasno określonych rolach (Product Owner, Scrum Master, Zespół),
o regularnych spotkaniach (planowanie sprintu, daily scrum, review,
retrospektywa).
Celem Scruma jest zwiększenie efektywności zespołu, szybkie reagowanie na
zmiany oraz dostarczanie działających przyrostów produktu.
22. Omów funkcje i narzędzia zarządzania zasobami ludzkimi w
organizacji.
Funkcje zarządzania zasobami ludzkimi (ZZL) to kluczowe działania obejmujące cały
cykl życia pracownika w organizacji, mające na celu pozyskanie, rozwój i utrzymanie
zaangażowanej kadry.
 Główne funkcje ZZL w organizacji:
▪ Planowanie zasobów ludzkich: Analiza potrzeb kadrowych i określenie
zapotrzebowania na pracowników w przyszłości.

--- page 42 ---

▪ Pozyskiwanie pracowników (Rekrutacja i selekcja): Wyszukiwanie,
wybór i zatrudnienie odpowiednich osób na konkretne stanowiska.
▪ Adaptacja (Onboarding): Wdrażanie nowych pracowników do firmy i
zapewnienie odpowiednich warunków pracy.
▪ Ocenianie pracowników (Appraisal): Ocena wyników pracy i
kompetencji pracowników.
▪ Rozwój pracowników (Development): Szkolenia, podnoszenie
kwalifikacji, planowanie ścieżek kariery i sukcesji.
▪ Motywowanie i wynagradzanie (Reward): Opracowywanie systemów
wynagrodzeń, benefitów oraz pozapłacowych metod motywowania.
▪ Utrzymanie kadry i relacje: Dbanie o zaangażowanie, atmosferę,
warunki pracy oraz relacje między kierownictwem a personelem.
 Narzędzia w nowoczesnym ZZL
▪ ATS (Applicant Tracking System): Systemy do zarządzania procesem
rekrutacji. Pozwalają śledzić status kandydatów i automatyzować
komunikację.
▪ Model kompetencyjny: Zbiór cech i umiejętności pożądanych na
danym stanowisku. Pomaga obiektywnie oceniać ludzi.
▪ Wywiad Behawioralny (STAR): Technika prowadzenia rozmowy
kwalifikacyjnej skupiona na przeszłych zachowaniach (Sytuacja,
Zadanie, Akcja, Rezultat), co pozwala przewidzieć przyszłą
skuteczność kandydata.

--- page 43 ---

▪ Coaching i Mentoring: Indywidualne formy wsparcia. Mentor to
doświadczony pracownik dzielący się wiedzą, a coach pomaga
pracownikowi samemu odnaleźć rozwiązania i potencjał.
▪ Grywalizacja (Gamification): Wykorzystanie mechanizmów znanych z
gier (punkty, rankingi, odznaki) do zwiększenia zaangażowania w
codzienne, czasem nudne zadania.
23. Przedstaw podstawowe teorie i instrumenty motywowania.
Podstawowe teorie motywowania
▪ Hierarchia potrzeb Maslowa: ludzie motywowani są przez zaspokojenie potrzeb
fizjologicznych bezpieczeństwa przynależności uznania i samorealizacji
pracownik najpierw skupia się na podstawowych na przykład pensja a dopiero po
ich zaspokojeniu na wyższych celach na przykład awans.
▪ Teoria dwuczynnikowa Herzberga: Dzieli czynniki na:
● Higieny (płaca, warunki pracy, relacje) – ich brak powoduje
niezadowolenie, ale ich obecność nie motywuje trwale.
● Motywatory (osiągnięcia, uznanie, treść pracy, awans) – to one budują
rzeczywiste zaangażowanie.
▪ Teoria oczekiwań Vrooma: Zakłada, że pracownik będzie zmotywowany, jeśli
wierzy, że: jego wysiłek przyniesie efekt, efekt przyniesie nagrodę, a nagroda
będzie dla niego wartościowa.
▪ Teoria sprawiedliwości Adamsa: Pracownik porównuje swój nakład pracy i
otrzymane nagrody z nakładami i nagrodami innych osób. Jeśli czuje się
traktowany niesprawiedliwie, jego motywacja spada.
▪ Teoria X i Teoria Y Douglasa McGregora: Douglas McGregor stworzył dwie
przeciwstawne teorie dotyczące podejścia do zarządzania pracownikami. Teoria X
zakłada, że ludzie są leniwi, nie lubią pracy i potrzebują stałego nadzoru. W

--- page 44 ---

przeciwieństwie do niej, teoria Y zakłada, że ludzie są z natury aktywni, ciekawi i
ambitni. Zarządzanie oparte na Teorii Y promuje autonomię, zaufanie i
odpowiedzialność pracowników. Od tego jakie podejście wybierzesz, będzie
zależał poziom motywacji Twojego zespołu.
Instrumenty motywowania (Narzędzia) - W zarządzaniu dzielimy je na trzy
główne grupy:
1) Instrumenty płacowe (Finansowe bezpośrednie):
● Wynagrodzenie zasadnicze (pensja).
● Premie i nagrody pieniężne.
● Prowizje od sprzedaży.
● Udziały w zyskach firmy.
2) Instrumenty pozapłacowe (Finansowe pośrednie / Benefity):
● Pakiety medyczne i sportowe.
● Samochód służbowy, telefon, laptop.
● Dofinansowanie do szkoleń i nauki języków.
3) Instrumenty niematerialne (Psychologiczne):
● Uznanie i pochwały: Oficjalne podziękowanie od przełożonego.
● Awans pionowy i poziomy: Zmiana stanowiska na wyższe lub rozszerzenie
zakresu odpowiedzialności.
● Elastyczny czas pracy: Możliwość pracy zdalnej (Home Office).
● Treść pracy: Powierzanie ambitnych, ciekawych zadań.
24. Klasyczne i nowoczesne struktury organizacyjne. Podaj
przykłady.
Klasyczne struktury organizacyjne
Opierają się na silnej hierarchii, centralizacji decyzji i sztywnym podziale
obowiązków.
Struktura liniowa
Istnieje jedna linia podporządkowania – każdy podwładny ma dokładnie jednego
przełożonego, od którego otrzymuje polecenia.

--- page 45 ---

• Cechy: Jasna linia władzy, wysoka dyscyplina, szybkość podejmowania
decyzji.
• Przykład: Małe firmy rodzinne (np. lokalny warsztat), małe jednostki
wojskowe.
Struktura funkcjonalna
Pracownicy są grupowani według specjalizacji (funkcji). Charakterystyczne jest tu
występowanie tzw. wielostronnego podporządkowania – pracownik może
otrzymywać polecenia od różnych kierowników funkcjonalnych (np. od szefa
marketingu i szefa produkcji).
• Cechy: Wysoka specjalizacja kadry kierowniczej, lepsze wykorzystanie
wiedzy ekspertów.
• Przykład: Tradycyjne urzędy, działy w średniej wielkości
przedsiębiorstwach.
Struktura liniowo-sztabowa
Istnieje linia dowodzenia (kierownicy liniowi), ale mają oni do pomocy komórki
doradcze (sztab), które posiadają wiedzę fachową, ale nie mają uprawnień
decyzyjnych wobec pracowników liniowych.
• Cechy: Wsparcie fachowe dla kierowników przy zachowaniu jedności
dowodzenia.
• Przykład: Duże zakłady produkcyjne posiadające działy prawne lub
analityczne.
Struktura dywizjonalna
Duże organizacje dzielą się na mniejsze jednostki (dywizje) według produktów,
rynków geograficznych lub grup klientów. Każda dywizja ma dużą samodzielność
(własny HR, marketing).

--- page 46 ---

• Cechy: Odciążenie zarządu od bieżących decyzji, szybka reakcja na
potrzeby konkretnego rynku.
• Przykład: Korporacje wieloproduktowe, np. Nestlé (osobne dywizje na
słodycze, napoje, karmę dla zwierząt).
Nowoczesne struktury organizacyjne
Powstały jako odpowiedź na dynamiczne zmiany w otoczeniu. Są bardziej elastyczne
i zdecentralizowane.
Struktura macierzowa
Pracownicy są przypisani jednocześnie do działów funkcjonalnych (pionów) oraz do
konkretnych projektów. Oznacza to "podwójne podporządkowanie" – pracownik ma
szefa działu (np. IT) i szefa projektu (np. budowa aplikacji X).
• Cechy: Bardzo wysoka elastyczność, świetna koordynacja prac
projektowych.
• Przykład: Firmy informatyczne (Software Houses), agencje reklamowe,
firmy doradcze (np. Deloitte).
Struktura procesowa (płaska)
• Opis: Koncentruje się na procesach biznesowych (przepływie pracy), a nie
na funkcjach. Działy są zastępowane zespołami procesowymi.
• Przykład: Firma e-commerce, w której zespół „Od zamówienia do dostawy”
obejmuje osoby z działu logistyki, obsługi klienta i magazynu,
współpracujące razem.
Struktura sieciowa
Firma skupia się na swoich kluczowych kompetencjach (np. projektowanie), a resztę
funkcji (np. księgowość, logistykę, produkcję) zleca partnerom zewnętrznym
(outsourcing). Więzi między podmiotami przypominają sieć.
• Cechy: Niskie koszty stałe, ogromna szybkość adaptacji do rynku.

--- page 47 ---

• Przykład: Nike lub Dell (Nike głównie projektuje i promuje, podczas gdy
produkcja odbywa się w niezależnych fabrykach na całym świecie).
25. Scharakteryzuj podstawowe style kierowania wykorzystywane
przez menedżerów.
Klasyczna klasyfikacja stylów (według K. Lewina)
 Styl autokratyczny (Autorytarny):
● Istota: Menedżer sam podejmuje wszystkie decyzje i wydaje
szczegółowe polecenia. Nie konsultuje się z zespołem. Potrzeby i
emocje pracowników są podporządkowane celem przedsiębiorstwa.
● Kontrola: Bardzo ścisła; menedżer skupia się na zadaniach, a nie na
relacjach. Często chcę zmotywowania pracowników ukształca się
system kar ostra krytyka natomiast nagrody należą do rzadkości.
Pracownicy są całkowicie uzależnieni od opinii i decyzji lidera.
● Zalety: Szybkość podejmowania decyzji, skuteczność w sytuacjach
kryzysowych.
● Wady: Brak inicjatywy pracowników, niska motywacja, ryzyko błędów
lidera. Pracownicy są pozbawieni możliwości rozwoju skutkuje to
obniżeniem się efektywności i jakości pracy pracownicy przestają się
identyfikować z firmą dochodzi frustracja wypalenie zawodowe i zła
komunikacja jest również częstą rzeczą.
● Szef wydaje konkretne polecenia według własnego uznania i wymaga
ich realizacji pracownik nie ma możliwości dodania własnych uwag lub
dodania własnych pomysłów musi podporządkować się sposobu pracy i
decyzją przez przełożonego i okazywać względem niego
posłuszeństwo.
● Zaletą na pewno jest to że rzadko dochodzi do nieporozumień
każdy pracownik ma plan termin wykonania zadań

--- page 48 ---

 Styl demokratyczny:
● Istota: Menedżer zachęca grupę do współuczestnictwa w
podejmowaniu decyzji. Deleguje uprawnienia i konsultuje się z
pracownikami. Zespół nie dąży do konfliktów ale do skutecznego
rozwiązania problemu.
● Kontrola: Oparta na zaufaniu i wynikach, a nie na ciągłym nadzorze.
● Zalety: Wysokie zaangażowanie, kreatywność zespołu, lepsza
atmosfera. Znaczy kierownik traktuje swoich pracowników w sposób
partnerski i życzliwy bierze ich pomysły pod uwagę tej konkretne
polecenia cele działania ale zostawia swobodę w kwestii metod
wykonywania pracy trwała dobrą losowo atmosferę , przede wszystkim
przynosi na pracowników część odpowiedzialności, jeśli nastąpi krytyka
musi być oparta na konkretnych przykładach.
● Wady: Czasochłonność procesu podejmowania decyzji. Długo się
podejmuje decyzję długie dyskusje są może być spadek dyscypliny.
➢ Styl liberalny (Laissez-faire / Pozwalający):
● Istota: Menedżer pozostawia pracownikom pełną swobodę w
podejmowaniu decyzji i realizacji zadań. Sam unika ingerencji. Tylko
jeśli w stanie poproszony to udziela wskazówek.
● Zalety: Idealny dla zespołów wysokiej klasy specjalistów i naukowców
(ekspertów). Pracownicy czują się niezależni i docenieni praca jest
dobra dobrym atmosferze taki styl się sprawdza w małych zespołach Bo
ludzie są skoncentrowani na celach firmy
● Wady: Częsty brak dyscypliny, ryzyko chaosu i dezorientacji w zespole.
Zazwyczaj skutkuje niską efektywnością pracy często członkowie
skupiają się głównie własnych celach do uzyskania niezależności
samodzielności w organizacji nie angażują się w pracy zespołową
kierownictwo nie przekazuje informacyjnych zwrotnych zatrudnienie
intensywnie mogą wiedzieć o swoich błędach nie rozwijają się brak
kontroli również spowodować działania na szkodę firmy.

--- page 49 ---

26. Omów zasady funkcjonowania gospodarki rynkowej.
Gospodarka rynkowa opiera się na kilku kluczowych zasadach:
• Dominacja własności prywatnej. Własność prywatna jest podstawą
podejmowania decyzji gospodarczych. Przedsiębiorstwa i gospodarstwa
domowe zarządzają zasobami, dążąc do maksymalizacji zysków.
• Wolność konkurencji. Rynki w gospodarce rynkowej charakteryzują się
konkurencją między przedsiębiorstwami, co prowadzi do obniżania cen,
poprawy jakości dóbr i usług oraz innowacji.
• Samoregulacja. Mechanizmy rynkowe, takie jak popyt i podaż, naturalnie
regulują ilość dóbr i usług dostępnych na rynku, wpływając na ich ceny. Ceny
pełnią funkcję informacyjną wskazując które dobra są rzadkie oraz motywacje
składające z procentów do wytwarzania poszczególnych towarów.
• Swobodny obrót towarami. W gospodarce rynkowej możliwy jest swobodny
obrót towarami. Podmioty gospodarcze mogą kupować i sprzedawać dobra
oraz usługi na wolnym rynku, co sprzyja dynamice i elastyczności gospodarki.
Dzięki temu gospodarka może szybko reagować na zmieniające się warunki
rynkowe.
• Ograniczona ingerencja państwa. W gospodarce rynkowej rola państwa
jest ograniczona do minimum. Państwo pełni funkcję regulatora, dbając o to,
aby zasady wolnej konkurencji były przestrzegane i chronione. W wyjątkowych
sytuacjach, takich jak klęski żywiołowe, państwo może interweniować, ale na
co dzień jego wpływ na gospodarkę jest niewielki.
27. Przedstaw podstawowe kierunki działania Planu Balcerowicza
oraz jego skutki społeczne i gospodarcze.

--- page 50 ---

 Podstawowe kierunki działania (Filary Planu)
• Stabilizacja makroekonomiczna – głównym celem było powstrzymanie
gigantycznej inflacji (hiperinflacji) poprzez drastyczne ograniczenie wydatków
państwa i zaostrzenie polityki pieniężnej.
• Uwolnienie cen – zniesiono urzędową kontrolę nad większością cen,
pozwalając, aby to rynek (popyt i podaż) decydował o wartości towarów.
• Wprowadzenie wymienialności złotego – ujednolicono kurs dolara i
pozwolono na swobodny handel walutami, co otworzyło Polskę na rynki
zagraniczne.
• Prywatyzacja i restrukturyzacja – rozpoczęto proces przekazywania
państwowych przedsiębiorstw w ręce prywatne oraz likwidację nierentownych
zakładów.
• Likwidacja monopolu w handlu zagranicznym – umożliwienie każdej
firmie bezpośredniego importu i eksportu towarów bez pośrednictwa państwa.
 Skutki gospodarcze (Konkrety)
• Opanowanie hiperinflacji – udało się szybko zdusić wzrost cen, co
ustabilizowało wartość pieniądza.
• Uwolnienie cen i zniesienie centralnego planowania dzięki temu zniknęły
niedobory towarów.
• Likwidacja niedoborów rynkowych – towary niemal natychmiast pojawiły
się na sklepowych półkach, kończąc erę kartek i kolejek.
• Powstanie sektora prywatnego – nastąpił gwałtowny rozwój
przedsiębiorczości; powstały tysiące nowych, prywatnych firm.
• Wzrost jakości produktów – konkurencja wymusiła na producentach lepszą
jakość i nowoczesność towarów.

--- page 51 ---

• W krótkim okresie nastąpił spadek produkcji PKB ponieważ wiele
przedsiębiorstw państwowych nie wytrzymało konkurencji rynkowej.
 Skutki społeczne (Trudne aspekty)
• Pojawienie się bezrobocia – w wyniku likwidacji państwowych zakładów
(szczególnie PGR-ów) miliony ludzi straciły pracę, co było ogromnym szokiem
społecznym.
• Spadek realnych dochodów – w początkowej fazie reform wiele rodzin
gwałtownie ubożało z powodu zamrożenia płac przy jednoczesnym wzroście
cen.
• Rozwarstwienie społeczne – powstały duże różnice majątkowe między
osobami, które odnalazły się w nowym systemie, a tymi, które straciły
poczucie bezpieczeństwa socjalnego.
• Stres i niepewność – nagłe przejście do kapitalizmu wywołało u wielu osób
poczucie zagubienia i lęk przed przyszłością
• wzrost przedsiębiorczości-z czasem wzrosła samodzielność i aktywność
społeczeństwa pojawił się nowe możliwości pracy i prowadzenie działalności.
28. Opisz wpływ podatków, dotacji i kredytów rządowych na
prowadzenie przedsiębiorstwa.
 Wpływ podatków na przedsiębiorstwo
• Zmniejszenie zysku i kapitału – podatki takie jak CIT czy PIT to
obowiązkowe obciążenia, które bezpośrednio obniżają dochód netto firmy oraz
ilość pieniędzy dostępnych na bieżące wydatki (kapitał obrotowy).
• Wysokie podatki zabierają firmie gotówkę, którą mogłaby wydać na to,
żeby stać się większą i lepszą.

--- page 52 ---

• Problemy z płynnością (VAT) – konieczność zapłaty podatku VAT do
urzędu, zanim firma otrzyma pieniądze od klienta, może prowadzić do
powstawania zatorów płatniczych i braku gotówki w kasie.
• Ryzyko szarej strefy – zbyt skomplikowany i drogi system podatkowy może
zniechęcać do inwestowania w kraju, a w skrajnych przypadkach zmuszać
firmy do ucieczki za granicę lub ucieczki do szarej strefy.
• Optymalizacja kosztów – przedsiębiorca może wybrać formę
opodatkowania (np. Ryczałt lub podatek liniowy), co pozwala legalnie
zmniejszyć obciążenia i jest kluczowe dla przetrwania małych firm.
 Wpływ dotacji
• Bezzwrotne wsparcie – dotacje to darmowe środki, które mają zachęcać
firmy do konkretnych działań, takich jak dbanie o ekologię, zwiększanie
zatrudnienia czy wdrażanie innowacji.
• Rozwój technologii– dzięki dotacjom firmy mogą kupować nowoczesne
maszyny i oprogramowanie, na które nie byłoby ich stać przy wykorzystaniu
tylko własnych oszczędności.
• Ułatwiony start – pieniądze z urzędów pracy lub funduszy UE są kluczowe
dla nowych firm, ponieważ zapewniają im bezpieczeństwo finansowe na
samym początku działalności.
• Budowanie przewagi – firmy korzystające z dotacji mają niższe koszty
inwestycji, dzięki czemu mogą oferować klientom lepsze ceny i wyższą jakość
niż konkurencja.
 Wpływ kredytów i pożyczek rządowych
• Preferencyjne warunki – kredyty z gwarancjami państwowymi (np. Z BGK)
są tańsze niż te w zwykłych bankach, mają niższe oprocentowanie i dłuższy
czas na spłatę.

--- page 53 ---

• Tarcza podatkowa – odsetki od kredytów firma wpisuje w koszty
prowadzenia działalności, co pozwala legalnie zapłacić niższy podatek
dochodowy.
• Szybka ekspansja – pożyczone pieniądze pozwalają na tzw. Dźwignię
finansową, czyli szybkie zatrudnienie ludzi i zakup towaru, co gwałtownie
zwiększa skalę sprzedaży.
• Dostęp dla małych firm – dzięki rządowym poręczeniom, nawet firmy z
krótką historią na rynku mogą otrzymać finansowanie, którego zwykły bank by
im odmówił.
• Ryzyko zadłużenia – należy jednak uważać, ponieważ zbyt duża liczba
kredytów może stać się niebezpieczna dla firmy w momencie, gdy pogorszy
się sytuacja na rynku i spadną zyski.
29. Omów skutki wprowadzenia ceł ochronnych oraz cen
minimalnych i maksymalnych.
Skutki wprowadzenia ceł ochronnych
Cło to dodatkowa opłata nakładana na towary sprowadzane z zagranicy. Ma ono
„utrudnić” życie zagranicznym firmom, aby te krajowe miały łatwiej.
• Wzrost cen towarów z importu – towary sprowadzane z zagranicy stają się
droższe, przez co klienci rzadziej je wybierają.
• Ochrona rodzimych producentów – polskie firmy mogą sprzedać więcej
swoich towarów, bo zagraniczna konkurencja przestała być dla nich tak groźna
cenowo.
• Większe wpływy do budżetu państwa – każde zapłacone cło to dodatkowy
pieniądz dla państwa.
• Ryzyko „wojny celnej” – inne kraje mogą się obrazić i w odwecie nałożyć cła
na nasze towary, co uderzy w naszych eksporterów.

--- page 54 ---

• Mniejszy wybór dla klienta – przez wysokie cła niektóre zagraniczne produkty
mogą całkowicie zniknąć z półek.
Skutki wprowadzenia cen minimalnych
Cena minimalna to najniższa cena, za jaką można sprzedać dany produkt.
• Powstanie nadwyżki rynkowej – ponieważ cena jest wysoka, producenci
chcą sprzedawać bardzo dużo, ale klienci nie chcą tyle kupować po takiej
cenie. W efekcie magazyny są pełne towaru, którego nikt nie chce.
• Wzrost cen dla konsumentów – my jako zwykli kupujący, musimy płacić za
dany produkt więcej niż gdyby państwo nie ingerowało.
• Konieczność skupu nadwyżek przez państwo – skoro nikt nie chce kupić
towaru po cenie minimalnej, państwo często musi go samo odkupić od
rolników, co kosztuje nas wszystkich (z podatków).
• Hamowanie innowacji – skoro producenci mają zagwarantowaną wysoką
cenę, nie starają się ulepszać swoich produktów ani obniżać kosztów
produkcji.
• Ochrona określonych grup (np. Rolników): Ceny minimalne gwarantują
producentom minimalny dochód, co jest często używane do stabilizacji
dochodów w rolnictwie.
Skutki wprowadzenia cen maksymalnych
Cena maksymalna to cena, powyżej której nie wolno sprzedawać.
• Powstanie niedoboru (braków) – cena jest tak niska, że ludzie chcą kupować
masowo, ale firmom nie opłaca się tego produkować lub sprzedawać. Towar
znika z półek.

--- page 55 ---

• Pojawienie się „czarnego rynku” – skoro towaru brakuje w sklepach, ludzie
zaczynają nim handlować „pod ladą” po znacznie wyższych cenach.
• Spadek jakości – producenci, którzy nie mogą podnieść ceny, zaczynają
oszczędzać na składnikach lub materiałach, żeby cokolwiek zarobić.
• Kolejki i limity – państwo często musi wprowadzać ograniczenia (np. Tylko 2
opakowania na osobę), bo towaru jest za mało dla wszystkich.
30. Wskaż krótko- i długoterminowe efekty inflacji.
➢ Krótkoterminowe efekty inflacji
● Spadek realnych dochodów: Konsumenci za tę samą pensję mogą kupić
mniej towarów, co obniża standard życia.
● Spadek siły nabywczej pieniędzy pieniądz traci wartość – pensja
nominalnie może być taka sama, ale realnie starcza na mniej.
● Wzrost kosztów produkcji: Firmy płacą więcej za surowce i energię, co
wymusza podnoszenie cen produktów lub cięcie kosztów (np. Redukcję
zatrudnienia).
● Efekt „konia wyścigowego”: Ludzie częściej kupują produkty, obawiając się
wyższych cen w przyszłości, co tymczasowo napędza sprzedaż.
● Zwiększenie stóp procentowych: Banki centralne podnoszą stopy, co
zdroża kredyty.
➢ Długoterminowe efekty inflacji (długi okres):
● Zniszczenie oszczędności: Oszczędności gromadzone na lokatach o niskim
oprocentowaniu tracą realną wartość, co uderza w osoby starsze i
oszczędzające.
● Niepewność gospodarcza i brak inwestycji: Wysoka, zmienna inflacja
zniechęca firmy do długoterminowego planowania i inwestowania, co hamuje
rozwój gospodarczy.
● Redystrybucja dochodów: Inflacja faworyzuje dłużników (realna wartość
długu spada) kosztem wierzycieli.

--- page 56 ---

● Spadek konkurencyjności międzynarodowej: Jeśli krajowe ceny rosną
szybciej niż za granicą, eksport staje się droższy i mniej atrakcyjny.
● Dostosowanie oczekiwań (spirala płacowo-cenowa): Pracownicy żądają
wyższych płac, co zmusza firmy do dalszych podwyżek cen, utrwalając
wysoką inflację.
Lista zagadnień na egzamin dyplomowy – Specjalność:
„Digital Marketing”:
1. Przedstaw i omów podział mediów e-marketingu wg modelu
POEM (Paid Owned Earned Media) – podaj przykładowe kanały z
każdej kategorii.
Owned Media (Media Własne)
Są to kanały komunikacji, które należą bezpośrednio do marki. Masz nad nimi pełną
kontrolę – to Ty decydujesz, co, kiedy i jak publikujesz.
Cel: Budowanie długofalowych relacji i dostarczanie wartościowych treści.
o Przykładowe kanały:
• Strona internetowa firmy lub sklep online.
• Firmowy blog.
• Newsletter (e-mail marketing).
• Profile w mediach społecznościowych (choć technicznie należą do platformy,
treść na nich jest Twoja).
• Aplikacje mobilne marki.

--- page 57 ---

Paid Media (Media Płatne)
Są to wszystkie działania, za które firma musi zapłacić, aby wyświetlić swój przekaz
odbiorcom. Służą one głównie do szybkiego budowania zasięgu i pozyskiwania
nowych klientów.
Cel: Generowanie ruchu, szybka sprzedaż i zwiększanie rozpoznawalności.
o Przykładowe kanały:
• Reklamy w wyszukiwarkach (np. Google Ads).
• Płatne reklamy w social mediach (np. Facebook Ads, Instagram Ads).
• Artykuły sponsorowane na portalach zewnętrznych.
• Reklamy banerowe (display).
• Współpraca z influencerami (model płatny).
Earned Media (Media Pozyskane)
To „najcenniejsza” kategoria, ponieważ obejmuje darmowy rozgłos, który marka
zdobywa dzięki zaangażowaniu użytkowników. To inni mówią o Tobie, co buduje
ogromną wiarygodność.
Cel: Budowanie zaufania (Social Proof) i autorytetu marki.
o Przykładowe kanały:
• Recenzje i opinie klientów (np. W Google, na Facebooku).
• Udostępnienia Twoich treści przez użytkowników (share).
• Wzmianki o marce na forach lub w postach innych osób.
• Publikacje redakcyjne (gdy dziennikarz sam napisze o Twoim produkcie).

--- page 58 ---

2. Omów podstawowe różnice w podejściu jednokanałowym, przez
Multichannel, Cross Channel, Omnichannel. Podaj przykłady
funkcjonalności omnichannel.
Jednokanałowe (Single Channel):
Opis: Firma korzysta tylko z jednej ścieżki dotarcia do klienta (np. Tylko sklep
stacjonarny lub tylko jeden sklep internetowy).
Podejście: Skupienie na produkcie lub jednej metodzie sprzedaży.
Przykład: Mały butik odzieżowy działający wyłącznie fizycznie.
Multichannel (Wielokanałowe):
Opis: Firma sprzedaje w wielu kanałach (np. Sklep stacjonarny, e-sklep, social
media), ale funkcjonują one niezależnie od siebie.
Podejście: Skupienie na marce i produkcie – celem jest maksymalna widoczność.
Kanały często ze sobą rywalizują.
Różnica: Klienci doświadczają rozproszonego, różnego doświadczenia w zależności
od kanału.
Cross-Channel (Międzykanałowe):
Opis: Firma korzysta z wielu kanałów, które są ze sobą skoordynowane.
Podejście: Integracja kanałów w celu ułatwienia zakupów (np. Możliwość
sprawdzenia dostępności w sklepie przez stronę www).

--- page 59 ---

Różnica: Kanały współpracują, ale nie tworzą pełnej, jednolitej całości. Nie są
zintegrowane, ale na przykład kiedy klient widzi na Facebooku promocję używa kodu
w sklepie internetowym jest spójność komunikacji i umożliwienie klientom łatwego
przechodzenia między kanałami.
Omnichannel (Wielokanałowość zintegrowana):
Opis: Wszystkie kanały (fizyczne i cyfrowe) są w pełni zintegrowane, oferując spójne,
płynne doświadczenie.
Podejście: Skupienie na kliencie – klient jest w centrum, a nie produkt. Przejście
między kanałami (np. Telefon -> sklep stacjonarny -> strona www) jest
niezauważalne.
Różnica: Pełna integracja danych i spójność przekazu
 Przykłady funkcjonalności Omnichannel:
Omnichannel opiera się na integracji danych o kliencie, stanach magazynowych i
komunikacji. Oto główne przykłady:
• BOPIS (Buy Online, Pick Up In-Store): Klient kupuje produkt online, a
odbiera go w wybranym sklepie stacjonarnym w ciągu godziny.
• BORIS (Buy Online, Return In-Store): Możliwość zwrotu towaru kupionego w
sklepie internetowym w dowolnym sklepie fizycznym (i odwrotnie).
• Sprawdzanie dostępności na żywo (Real-time Inventory): Klient na stronie
www sprawdza, czy produkt jest fizycznie w konkretnym sklepie stacjonarnym.
• Aplikacje mobilne w sklepie (In-store App Experience): Skanowanie kodów
kreskowych produktów w sklepie za pomocą aplikacji, aby sprawdzić opinie,
dostępność rozmiarów lub zamówić towar do domu, jeśli go nie ma na półce.
• Unified Customer Profile (Spójny profil klienta): Sprzedawca w sklepie
stacjonarnym widzi historię zakupów i listę życzeń klienta, którą stworzył on na
stronie internetowej, co pozwala na spersonalizowaną obsługę.

--- page 60 ---

3. Omów etapy tworzenia strategii mediowej.
1. Analiza sytuacji wyjściowej (Research & Audit)
• Audyt marki: Co oferujemy i jakie mamy przewagi (USP)?
• Analiza konkurencji: Gdzie i jak reklamują się nasi rywale?
• Analiza SWOT: Określenie mocnych i słabych stron oraz szans i zagrożeń dla
kampanii.
2. Definicja grupy docelowej (Audience Insights)
• Dane demograficzne i psychograficzne: Wiek, lokalizacja, ale też zainteresowania i
wartości.
• Ścieżka konsumenta (Customer Journey): Zrozumienie, jakich mediów używa klient
na każdym etapie – od dowiedzenia się o marce do zakupu.
3. Ustalenie celów i wskaźników KPI
Cele muszą być mierzalne i określone w modelu SMART.
• Cele: Np. świadomość marki (zasięg), ruch na stronie lub sprzedaż (konwersja).
• Wskaźniki KPI: Konkretne liczby, które sprawdzamy: CPM (koszt wyświetleń), CPC
(koszt kliknięcia), CPA (koszt pozyskania klienta).
4. Wybór kanałów (Media Mix Strategy)
Decyzja o doborze mediów w oparciu o model POEM:
• Owned (własne, np. strona WWW), Paid (płatne, np. Facebook Ads, Google Ads),
Earned (zdobyte, np. opinie).

--- page 61 ---

• Dbanie o Omnichannel, czyli spójność przekazu w każdym z tych kanałów.
5. Opracowanie budżetu i harmonogramu (Budget & Scheduling)
• Alokacja budżetu: Podział pieniędzy na kanały, które dają najlepszy zwrot.
• Harmonogram (Flighting): Ustalenie, kiedy kampania ma być intensywna (np. tylko
w weekendy, pulsacyjnie lub ciągle).
6. Wdrożenie i kreacja
• Przygotowanie kreacji: Tworzenie grafik i tekstów dopasowanych do specyfiki
kanału (inny post na TikTok, inny na LinkedIn).
• Zakup mediów (Media Buying): Techniczne uruchomienie reklam i rezerwacja
powierzchni.
7. Optymalizacja i raportowanie (Measurement)
• Optymalizacja: Jeśli reklama na Facebooku działa lepiej niż w Google, przesuwamy
tam budżet w trakcie trwania kampanii.
• Raportowanie: Podsumowanie wyników i wyciągnięcie wniosków na kolejne
kampanie.
4. Scharakteryzuj rodzaje kampanii mediowych ze względu na
realizowane przez nie cele.
 Kampanie Świadomościowe (Awareness / Brand Building)
Ich celem nie jest natychmiastowa sprzedaż, ale sprawienie, by klient dowiedział się
o istnieniu marki lub produktu.
• Cel: Zbudowanie rozpoznawalności, zasięgu i pozytywnego wizerunku.
• Kiedy stosujemy: Wprowadzanie nowego produktu na rynek (rebranding)
lub przypominanie o marce.

--- page 62 ---

• Kluczowe wskaźniki (KPI): * Zasięg (Reach) ,Liczba wyświetleń
(Impressions), Wzrost wyszukiwania nazwy marki w Google.
 Kampanie Edukacyjne
Skierowane do osób, które już znają kategorię produktu, ale szukają najlepszego
rozwiązania.
• Cel: Zaangażowanie odbiorcy, edukacja o zaletach produktu i skierowanie
ruchu na stronę WWW.
• Kiedy stosujemy: Gdy produkt jest złożony (np. Ubezpieczenie, elektronika)
i klient potrzebuje więcej informacji przed zakupem.
• Kluczowe wskaźniki (KPI): * CTR (Klikalność reklamy), Liczba interakcji
(komentarze, udostępnienia).
 Kampanie Sprzedażowe
To kampanie nastawione na konkretną akcję wykonaną przez klienta „tu i teraz”.
• Cel: Sprzedaż produktu, rejestracja w serwisie, zapis do newslettera (lead).
• Kiedy stosujemy: W bieżącej sprzedaży e-commerce, promocjach
cenowych, domykaniu procesu zakupowego.
• Kluczowe wskaźniki (KPI): * CR (Conversion Rate) , CPA / CPL, ROAS
 Kampanie Wizerunkowe
• Cel: Budowanie świadomości marki, jej reputacji oraz kształtowanie
pożądanego wizerunku w głowach odbiorców.
• Charakterystyka: Skupiają się na budowaniu zasięgu i rozpoznawalności.
Nie oczekujemy tu natychmiastowego zakupu, ale tego, by klient nas
zapamiętał.
• KPI: Zasięg (Reach), liczba wyświetleń (Impressions), wzrost świadomości

--- page 63 ---

 Kampanie Zaangażowania
• Cel: Budowanie relacji, edukacja i zachęcanie do interakcji (polubienia,
komentarze, wejścia na stronę).
• Charakterystyka: Budowanie społeczności i zaufania. Klient już o nas wie,
teraz ma nas „polubić” lub poznać szczegóły oferty
• KPI: Wskaźnik zaangażowania (Engagement Rate), liczba kliknięć (CTR),
liczba komentarzy/udostępnień, czas spędzony na stronie.
Konkrety;
▪ Wizerunkowa (brandingowa) – buduje świadomość i skojarzenia z marką;
długofalowa, duży zasięg, miękkie KPI (awareness, recall).
▪ Zasięgowa – dotarcie do jak największej liczby osób; krótkie, masowe formaty;
KPI: reach, frequency.
▪ Sprzedażowa (performance) – generuje sprzedaż/leady; nastawiona na
konwersje; KPI: ROAS, CPA, sprzedaż.
▪ Produktowa – promuje konkretny produkt/usługę; podkreśla cechy i korzyści;
KPI: zainteresowanie, trial.
▪ Launchowa – wprowadzenie nowości na rynek; intensywna w krótkim czasie;
KPI: buzz, szybka świadomość.
▪ Promocyjna – wsparcie rabatów/okresowych ofert; krótkoterminowa; KPI:
wzrost sprzedaży w czasie promo.

--- page 64 ---

▪ Edukacyjna – tłumaczy kategorię lub sposób użycia; content-heavy; KPI: czas
kontaktu, zaangażowanie.
5. Omów, jak działa wirtualny rynek programatyczny, wskaż
powiązania pomiędzy głównymi podmiotami: DSP, SSP, DMP i Ad
Exchange.
Model programatyczny (Programmatic Advertising) to zautomatyzowany sposób
kupowania i sprzedawania powierzchni reklamowej w czasie rzeczywistym (model
RTB-Real-Time Bidding). Zamiast negocjować z handlowcem, proces odbywa się w
milisekundach przy pomocy algorytmów.
Oto jak działają poszczególne podmioty i jak są ze sobą powiązane:
• DSP (Demand-Side Platform): Narzędzie dla reklamodawcy (kupującego). Pozwala
na zarządzanie wieloma kampaniami w jednym miejscu, ustawianie stawek i wybór
grupy docelowej. Tutaj ustawiasz kampanię określasz budżet i grupę docelową a
DSP szuka dla ciebie najlepszej okazji do zakupu.
• SSP (Supply-Side Platform): Narzędzie dla wydawcy (sprzedającego, np.
Właściciela portalu Onet czy bloga). Pomaga wydawcy sprzedać miejsce na stronie
za jak najwyższą cenę.
• Ad Exchange: Wirtualna giełda, na której spotykają się DSP i SSP. To tutaj odbywa
się licytacja powierzchni w ułamku sekundy.
• DMP (Data Management Platform): Magazyn danych. Dostarcza informacji o
użytkownikach (np. „kobieta, 25-30 lat, interesuje się podróżami”). Dzięki niej
reklamodawca wie, komu wyświetla reklamę.
Jak to działa? (Proces krok po kroku)
1. Użytkownik wchodzi na stronę: Gdy otwierasz stronę www, informacja o
Tobie trafia do SSP.

--- page 65 ---

2. Zapytanie do giełdy: SSP wysyła zapytanie do Ad Exchange: „Mam miejsce
na reklamę dla użytkownika X, kto da najwięcej?”.
3. Wzbogacenie o dane (DMP): Ad Exchange sprawdza w DMP, kim jesteś i
co lubisz, aby dopasować reklamę.
4. Aukcja (DSP): Różne platformy DSP (w imieniu marek) licytują się o to
wyświetlenie. Algorytm decyduje: „Ten użytkownik szukał rano butów, dam za
niego 2 zł”
5. Wygrana i emisja: Ten, kto zaoferował najwyższą stawkę przez swoje DSP,
wygrywa. Jego reklama ładuje się na stronie użytkownika.
Powiązania pomiędzy podmiotami (Relacje)
• DSP ↔ Ad Exchange: Reklamodawca wysyła ofertę kupna na giełdę.
• SSP ↔ Ad Exchange: Wydawca wystawia towar na giełdę.
• DMP ↔ DSP/Ad Exchange: Dane z DMP „podpowiadają” kupującemu (DSP), czy
dany użytkownik jest wart zakupu. Bez DMP reklama byłaby wyświetlana w ciemno.
Jeśli „dana osoba wygra” w klasycznym ujęciu, płaci stawkę drugiej
najwyższej oferty + 0,01. Jednak przy współczesnych aukcjach pierwszej ceny
wygrywający płaci swoją zaoferowaną stawkę.

--- page 66 ---

6. Podaj podstawowe założenia kreacji reklamowej typu display,
która realizuje cele budowania świadomości nowego

--- page 67 ---

produktu/oferty oraz takiej, która wpływa na cele sprzedażowe
reklamodawcy.
Kreacja display na Budowanie Świadomości (Awareness)
Cel: „wbić się” w pamięć użytkownika, który jeszcze nie zna marki – przyciągnąć
uwagę, ale bez nachalnej sprzedaży.
● Wyrazisty branding- Logo i kolory marki widoczne od pierwszego kontaktu z
reklamą. Emocjonalna warstwa wizualna- Zdjęcia lifestyle lub estetyczne
grafiki pokazujące produkt w użyciu.
● Krótki, zapamiętywany komunikat- Hasło budujące skojarzenie lub obietnicę
wartości, bez presji zakupu.
● Jasne USP- Proste pokazanie, jaką potrzebę rozwiązuje produkt lub co go
wyróżnia.
● Miękkie CTA- Zachęta do poznania marki („Sprawdź”, „Odkryj”, „Dowiedz się
więcej”).
Kreacja display na Cele Sprzedażowe (Performance)
Cel:
szybkie skłonienie do kliknięcia i wykonania akcji (zakup, lead)
● Produkt w centrum uwagi- Wyraźna ekspozycja na czystym tle, bez
zbędnych elementów.
● Mocna oferta cenowa- Cena, rabat lub promocja jako najbardziej widoczny
element. Poczucie pilności- Komunikaty ograniczające czas lub dostępność
oferty.
● Elementy zaufania- Bestseller, oceny, liczba klientów lub inne sygnały
wiarygodności.
● Silne CTA- Kontrastowy przycisk z jasnym komunikatem („Kup teraz”, „Do
koszyka”).
● Retargeting: Wykorzystanie spersonalizowanych reklam (dynamiczny
display), pokazujących produkty oglądane wcześniej przez użytkownika.

--- page 68 ---

7. Określ, jakie są kluczowe elementy pozycjonowania serwisu
WWW w zakresie tzw. SEO on-site (w ramach witryny).
1. Optymalizacja treści (Content)
To najważniejszy element. Google "czyta" stronę, więc treść musi być wartościowa.
• Słowa kluczowe (Keywords): Naturalne umieszczenie fraz, które wpisują
użytkownicy.
• Unikalność: Treść nie może być skopiowana z innej strony (tzw. Duplicate
Content).
• Aktualność i wartość: Teksty muszą wyczerpywać temat i odpowiadać na
intencje użytkownika.
2. Elementy strukturalne HTML
To sygnały dla robotów, o czym jest dana podstrona.
• Title Tag (Tytuł strony): Najważniejszy znacznik. Powinien zawierać słowo
kluczowe i zachęcać do kliknięcia.
• Nagłówki (H1, H2, H3): Hierarchia treści. H1 jest tylko jeden na stronę i
zawiera główny temat, H2 to podtytuły.
• mega tagi - title i description wpływające na widoczność w wynikach
wyszukiwania.
3. Optymalizacja techniczna i wydajność
Google promuje strony, które działają szybko i sprawnie.
• Szybkość ładowania (PageSpeed): Kluczowy czynnik. Długie ładowanie
zwiększa współczynnik odrzuceń.

--- page 69 ---

• Responsywność (Mobile-First Index): Strona musi idealnie wyświetlać się na
telefonach.
• Certyfikat SSL (HTTPS): Zielona kłódka – gwarancja bezpieczeństwa
danych.
4. Architektura i linkowanie
• Struktura adresów URL: Powinny być "przyjazne" (czytelne), np.
domena.pl/butybiegowe zamiast domena.pl/p=123.
• Linkowanie wewnętrzne: Prowadzenie użytkownika i robota po innych
podstronach serwisu (np. przez menu lub sekcję "podobne produkty").
• poprawna indeksacja – umożliwia wyszukiwarkom dostęp do istotnych
podstron
5. Optymalizacja grafik
Robot nie widzi obrazka, widzi kod.
• Atrybuty ALT: Opisy alternatywne zdjęć. Mówią robotowi, co jest na obrazku
(ważne też dla osób niewidomych).
• Kompresja: Zmniejszenie wagi plików graficznych bez straty jakości.
8. Opisz planowanie kampanii reklamowej Google Ads – w jaki
sposób dobierać słowa kluczowe, wykorzystując metody i
narzędzia.
Jak wygląda planowanie kampanii Google Ads i dobór słów kluczowych?

--- page 70 ---

1. Na początku trzeba wiedzieć, co chcemy osiągnąć – czy chcemy coś
sprzedać czy tylko ściągnąć ludzi na stronę. Od tego zależy, jakie słowa
wybierzemy.
2. Potem zastanawiamy się, co użytkownik wpisze w Google, kiedy będzie
szukał naszego produktu lub usługi. Szukamy takich haseł, które pasują do
oferty i mają sens sprzedażowy.
3. Do sprawdzenia tego używa się narzędzi, głównie Google Ads Keyword
Planner. To narzędzie pokazuje:
▪ Jak często dane słowo jest wyszukiwane,
▪ Ile może kosztować kliknięcie,
▪ Jak duża jest konkurencja.
4. Następnie wybieramy najlepsze słowa, grupujemy je tematycznie i
przypisujemy do konkretnych reklam. Usuwamy też słowa, które nie pasują
(tzw. Słowa wykluczające).
5. Po uruchomieniu kampanii sprawdzamy, które słowa działają, a które tylko
generują koszty — i na tej podstawie je poprawiamy.
Etapy Planowania Kampanii Google Ads
1. Określenie celu i struktury: Wybór celu (np. Sprzedaż, ruch w witrynie,
potencjalni klienci).
2. Definiowanie grupy docelowej i lokalizacji:Określenie, kim są odbiorcy i
gdzie przebywają.
3. Dobór słów kluczowych: Badanie fraz wpisywanych przez
użytkowników.
4. Konfiguracja budżetu i stawek: Ustalenie kosztów, które chcesz ponieść
(np. Za kliknięcie – CPC).

--- page 71 ---

5. Tworzenie kreacji reklamowych: Przygotowanie nagłówków i tekstów
reklam.
6. Uruchomienie i monitorowanie: Analiza wyników i optymalizacja.
Etapy dobierania słów kluczowych- Dobór słów kluczowych nie polega na
wypisaniu wszystkiego, co nam przyjdzie do głowy, ale na analizie lejka
sprzedażowego:
 Słowa ogólne (Short-tail): Krótkie frazy, np. „buty”. Mają duży zasięg, ale są
bardzo drogie i rzadko sprzedają (wysoki koszt, niska konwersja).
 Słowa z „długim ogonem” (Long-tail): Bardziej precyzyjne, np. „buty do
biegania po asfalcie damskie nike”. Mają mniejszy ruch, ale są tańsze i
generują bardzo wysoką sprzedaż (wysoka konwersja).
 Słowa brandowe: Nazwa Twojej firmy. Ważne, aby konkurencja nie
wyświetlała się nad Tobą.
 Słowa konkurencji: Licytowanie się na nazwy rywali (agresywna strategia).
Metody dopasowania słów kluczowych (Technikalia)
W Google Ads nie wystarczy podać słowa, musisz określić, jak bardzo „sztywno”
Google ma się go trzymać:

--- page 72 ---

• Dopasowanie przybliżone (Broad Match): System wyświetla reklamę na
podobne frazy, synonimy i błędy ortograficzne. (Duży zasięg, ryzyko
przepalenia budżetu).
• Dopasowanie do wyrażenia (Phrase Match): Słowo musi być zawarte w
zapytaniu (w cudzysłowie: „buty do biegania”).
• Dopasowanie ścisłe (Exact Match): Reklama pojawi się tylko, gdy ktoś
wpisze dokładnie tę frazę (w klamrach: [buty do biegania]).
• Wykluczające słowa kluczowe (Negative Keywords): Kluczowy element!
Dodajemy słowa, na które NIE chcemy się wyświetlać, np. „za darmo”,
„używane”, „praca”. Dzięki temu oszczędzamy budżet.
❖ Metoda Lejka (Intencja)
Dzielisz słowa na to, co klient chce zrobić:
▪ Informacyjne: „jak naprawić kran” (klient szuka wiedzy).
▪ Porównawcze: „najlepszy ranking baterii łazienkowych” (klient wybiera
model).
▪ Transakcyjne: „bateria Hansgrohe cena” (klient ma portfel w ręku).
❖ Metoda Długiego Ogona (Long-tail)
Zamiast ogólnego „buty”, celujesz w precyzyjne frazy: „czerwone buty do biegania po
asfalcie rozmiar 42”.
Efekt: Niższy koszt kliknięcia i wyższa sprzedaż.

--- page 73 ---

❖ Metoda „Seed Keywords” (Baza)
Wypisujesz główne kategorie swoich usług, a potem w Planerze Słów Kluczowych
sprawdzasz, jak ludzie realnie je wpisują i ile to kosztuje.
❖ Metoda Wykluczeń (Negative Keywords)
Od razu odrzucasz słowa, które marnują budżet, np.: za darmo, praca, używane,
forum, olx.
❖ Metoda Konkurencji
Używasz narzędzi (np. Semstorm, Senuto), żeby sprawdzić, na jakie słowa
wyświetlają się Twoi rywale i przejmujesz ich najlepsze frazy.
Narzędzia wspomagające planowanie
• Planer słów kluczowych Google (Keyword Planner): Podstawowe darmowe
narzędzie wewnątrz Google Ads. Pokazuje średnią miesięczną liczbę
wyszukiwań i przewidywany koszt za kliknięcie (CPC).
• Google Trends: Pozwala sprawdzić sezonowość (np. Kiedy ludzie zaczynają
szukać nart).
• Narzędzia zewnętrzne (np. Senuto, Semstorm, Ahrefs): Pozwalają
podejrzeć, na jakie słowa reklamuje się konkurencja.

--- page 74 ---

9. Wyjaśnij, jakie są różnice między autorskimi prawami osobistymi
a autorskimi prawami majątkowymi.
Autorskie prawa osobiste
Autorskie prawa osobiste chronią więź twórcy z utworem. Te prawa są niezbywalne i
bezterminowe. Nie da się ich zrzec lub przekazać i nigdy nie wygasają.
➢ Obejmują prawo do:
• autorstwa utworu,
• oznaczenia utworu swoim nazwiskiem lub pseudonimem albo do
udostępniania go anonimowo,
• nienaruszalności treści i formy utworu oraz jego rzetelnego wykorzystania,
• decydowania o pierwszym udostępnieniu utworu publiczności,
• nadzoru nad sposobem korzystania z utworu
Autorskie prawa majątkowe
Druga grupa praw autorskich, którymi objęte są utwory, to prawa majątkowe. Chronią
one interesy biznesowe twórcy utworu.
Te prawa są zbywalne – można je sprzedać, przekazać w całości lub częściowo
w ramach licencji, czasowe – wygasają po 70 latach od śmierci autora oraz
dziedziczne, czyli przechodzą na spadkobierców.
▪ Do autorskich praw majątkowych zalicza się:
• prawo do dysponowania utworem i korzystania z niego,
• prawo do wynagrodzenia za wykorzystanie utworu przez innych.
● Prawo do wynagrodzenia za wykorzystanie utworu przez innych
Każdemu twórcy przysługuje wynagrodzenie – tantiemy – za użycie utworu w
różnych mediach i miejscach np. w radiu, telewizji, Internecie, w czasie publicznych

--- page 75 ---

imprez takich jak koncerty czy wydarzenia sportowe. Opłaty za wykorzystanie mają
obowiązek wnosić zarówno firmy, jak i instytucje oraz osoby, które wykorzystują
utwory w swojej działalności.
Podsumowanie
• Prawa autorskie dzielą się na osobiste i majątkowe.
• Autorskie prawa osobiste są wieczne i niezbywalne. Chronią więź twórcy z
utworem.
• Autorskie prawa majątkowe są ograniczone czasowo i zbywalne. Można je
przekazać w ramach licencji lub przenieść na inny podmiot w pełnym zakresie.
10. Omów rodzaje treści i kanały dystrybucji treści w Content
Marketingu.
Rodzaje treści w content marketingu:
● Tekst (np. Na stronie www, blog, artykuł, wywiad, e-book, notka prasowa,
wpis na kanałach social media, e-mailing, newsletter)
● Wideo ( np. Webinary, vlog, animacja, filmy reklamowe, filmy na SM, shorty,
setki, wywiady)
● Audio (np. Podcast, wywiad w radio)
● Obrazkowe (np. Infografiki, grafiki, tabele)
● Treści interaktywne ( Quizy i ankiety)
● Treści generowane przez użytkowników (UGC)(Opinie i recenzje)
Kanały dystrybucji treści
 Kanały własne (owned media)
o Strona internetowa,
o Blog firmowy,
o Newsletter e-mail
o Profile marki w mediach społecznościowych.

--- page 76 ---

 Kanały zewnętrzne (earned media)
o Udostępnienia w social media,
o Rekomendacje i opinie użytkowników
o Publikacje gościnne
 Kanały płatne (paid media)
o Reklamy w social media,
o Reklamy display i wideo,
o Artykuły sponsorowane.
11. Przedstaw profil użytkowników i możliwości reklamowe trzech
wybranych platform społecznościowych.
Facebook
Profil użytkownika: Bardzo szeroki przekrój demograficzny. Obecnie dominuje
grupa 35-55+ lat. Młodsi użytkownicy (Gen Z) są mniej aktywni, ale starsze pokolenia
to najszybciej rosnąca grupa. Idealny do budowania społeczności lokalnych i grup
zainteresowań.
Możliwości reklamowe:
• Precyzyjne targetowanie: Możliwość dotarcia po zainteresowaniach,
wydarzeniach z życia (np. „zaręczeni”, „przeprowadzka”) czy zachowaniach.
• Formaty: Posty z obrazkiem/wideo, karuzele (kilka produktów w jednym),
reklamy w Messengerze,stories,reklamy in feed
• Retargeting: Zaawansowane śledzenie użytkowników za pomocą Piksela
Meta i konwersji (np. Porzucone koszyki)

--- page 77 ---

Instagram
Profil użytkownika: Głównie osoby w wieku 18-34 lata. Użytkownicy nastawieni na
inspiracje, modę, podróże, design i kulinaria. Bardzo duża rola tzw. Influencer
marketingu.
• Reels (Rolki): Krótkie, angażujące formy wideo (największe zasięgi obecnie).
• Stories: Reklamy pełnoekranowe wyświetlane między relacjami znajomych
• Instagram Shopping: Możliwość tagowania produktów bezpośrednio na
zdjęciach, co pozwala na zakup jednym kliknięciem
• Posty
• Współprace płatne: Systemowe oznaczanie postów sponsorowanych u
influencerów.
TikTok
Profil Użytkownika: Demografia: Zdominowana przez Gen Z (13-24), ale z bardzo
szybkim wzrostem grupy 25-34 i starszych [1].
Charakterystyka: Użytkownicy oczekują autentyczności, rozrywki, edukacji (TikTok
Edu) i szybkiego dostępu do trendów. Niski próg uwagi, wysoka interaktywność.
Możliwości Reklamowe:
• In-Feed Ads: Reklamy pojawiające się w trakcie przeglądania „Dla Ciebie”
(For You Page), wyglądające jak organiczne treści.
• TopView/Brand Takeover: Reklamy wyświetlane od razu po otwarciu aplikacji
(maksymalna widoczność).
• Branded Hashtag Challenge: Tworzenie wyzwań angażujących
użytkowników do tworzenia treści z marką.

--- page 78 ---

• TikTok Shop: Integracja zakupowa, pozwalająca na bezpośrednią sprzedaż
wideo
• Tik tiki i story – płatne współpracę
12. Omów, jak analizować skuteczność działań w ramach e-mail
marketingu. Scharakteryzuj metryki i wskaźniki.
Analiza skuteczności działań w e-mail marketingu
Analiza skuteczności e-mail marketingu polega na ocenie wyników kampanii na
podstawie metryk (danych liczbowych) oraz wskaźników (miar efektywności
obliczanych na ich podstawie). Pozwala to sprawdzić, czy działania realizują
założone cele komunikacyjne i biznesowe oraz wskazać obszary do optymalizacji.
Metryki w e-mail marketingu
Metryki to podstawowe, bezpośrednio mierzone dane, które opisują przebieg
kampanii:
▪ Liczba wysłanych e-maili – określa skalę kampanii.
▪ Liczba dostarczonych wiadomości – pokazuje skuteczność dostarczalności.
▪ Liczba otwarć – informuje, ilu odbiorców zapoznało się z wiadomością.
▪ Liczba kliknięć – wskazuje, ilu użytkowników weszło w interakcję z treścią.
▪ Liczba
konwersji –
pokazuje, ile osób
wykonało pożądaną
akcję (np. Zakup).
▪ Liczba
wypisań i zgłoszeń
spamu –

--- page 79 ---

sygnalizuje reakcje negatywne odbiorców.
Metody Analizy (Jak to robić dobrze?)
Aby analiza była pełna, profesjonaliści stosują:
• Testy A/B: Wysyłanie dwóch wersji maila do małych grup testowych (np. Z innym
tematem lub innym kolorem przycisku CTA). Wygrywa ta wersja, która ma lepsze
wskaźniki, i to ona idzie do reszty bazy.
• Analiza Mapy Kliknięć (Heatmapy): Sprawdzanie, w które konkretnie miejsca w
mailu ludzie klikają najchętniej.
• Segmentacja Bazy: Porównywanie wyników w różnych grupach (np. Czy kobiety
reagują lepiej na ofertę niż mężczyźni).
13. Wyjaśnij, jak budować bazę e-mail marketingową – przedstaw
motywacje i dobre praktyki rynkowe.
Motywacje użytkowników do zapisu (DLACZEGO się zapisują)
Użytkownicy pozostawiają adres e-mail, ponieważ:
• otrzymują korzyści finansowe (rabaty, kody),
• zyskują wartościowe treści (poradniki, e-booki),
• mają dostęp do ofert ekskluzywnych,
• ufają marce i jej eksperckiemu wizerunkowi.
• Wygoda otrzymywanie ważnych info w jedyny miejscu

--- page 80 ---

2. Jak budować bazę – prosty schemat krok po kroku
Krok 1: Wartość (Lead Magnet)
• Najpierw tworzysz magnes na zapis: rabat, e-book, webinar.
Krok 2: Miejsce (Punkty zapisu)
Formularz umieszczasz tam, gdzie jest użytkownik:
• landing page, pop-up, koszyk zakupowy, media społecznościowe.
Krok 3: Bezpieczeństwo (Double Opt-In)
• Użytkownik potwierdza zapis klikając link w e-mailu – baza jest legalna i
jakościowa.
Krok 4: Relacja (Welcome Mail)
• Wysyłasz mail powitalny z obiecaną korzyścią i informacją, co będzie dalej.
3. Dobre praktyki rynkowe (JAK ROBIĆ TO DOBRZE)
▪ jasna informacja o przetwarzaniu danych (RODO),
▪ łatwa rezygnacja z subskrypcji,
▪ segmentacja już na etapie zapisu,
▪ brak kupowania gotowych baz,
▪ regularne dbanie o jakość listy, single i opt in

--- page 81 ---

▪ Promocje pokazanie na górze w dużych liczbach
▪ Najwzjasze info na górze
▪ Metodą f czytania
▪ Wiadomości powitalne (Welcome Email): Stwórz silną serię powitalną, która
buduje relacje, bo ma najwyższe wskaźniki otwarć (open rate).
▪ Personalizacja i segmentacja: Dopasuj treść do preferencji odbiorcy, używaj
imienia i dziel bazę na segmenty, aby zwiększyć zaangażowanie.
▪ Używanie pre had era czyli pierwsze zdanie który mail odnajduje po tytule
14. Wymień i omów Heurystyki Nielsena

--- page 82 ---

15. Omów mechanizm emisji reklam w Internecie wraz z
występującymi na odpowiednich etapch wskaźnikami.
Etapy mechanizmu emisji reklam w Internecie
1. Wywołanie (Ad Request):
Opis: Użytkownik wchodzi na stronę internetową lub otwiera aplikację. Kod na
stronie (ad tag) wysyła sygnał do serwera reklamowego (Ad Server) lub platformy
SSP (SupplySide Platform) z informacją o dostępnym miejscu reklamowym, cechach
użytkownika i kontekście strony.
Wskaźniki: Ad Requests (liczba zapytań o reklamę).
2. Aukcja i Podejmowanie Decyzji (Ad Exchange/DSP/SSP):
Opis: SSP przekazuje ofertę do Ad Exchange, która organizuje licytację.
Demand-Side Platform (DSP) reprezentująca reklamodawców analizuje dane (np.
Pliki cookie, geolokalizacja) i automatycznie licytuje wyświetlenie reklamy, jeśli
użytkownik pasuje do grupy docelowej.
Wskaźniki: Bid Rate (procent zapytań, na które złożono ofertę), Win Rate (procent
wygranych aukcji).
3. Emisja Reklamy (Ad Serving/Rendering):
Opis: Zwycięska kreacja reklamowa jest wysyłana z serwera i renderowana
(wyświetlana) w przeglądarce lub aplikacji użytkownika.
Wskaźniki:
 Impression (Wyświetlenie): Reklama została załadowana.
 Viewable Impression (Widoczne Wyświetlenie): Reklama została
załadowana i była widoczna na ekranie (np. Min. 50% powierzchni przez 1
sekundę).
 Viewability Rate: Procent wyświetleń, które faktycznie były widoczne.

--- page 83 ---

 Reach (Zasięg): Liczba unikalnych użytkowników, którzy zobaczyli
reklamę.
4. Interakcja Użytkownika (User Interaction):
Opis: Użytkownik widzi reklamę i podejmuje (lub nie) działanie: klika, ogląda wideo,
ignoruje.
Wskaźniki:
 Clicks (Kliknięcia): Liczba kliknięć w reklamę.
 CTR (Click-Through Rate): Współczynnik klikalności (Kliknięcia /
Wyświetlenia).
 VTR (View-Through Rate): W przypadku wideo – procent obejrzanych reklam
w stosunku do wyświetlonych.
 Engagement Rate: Zaangażowanie (np. Najechanie kursorem, rozwinięcie
reklamy).
5. Konwersja i Raportowanie (Conversion & Reporting):
Opis: Użytkownik po kliknięciu wykonuje pożądaną akcję na stronie reklamodawcy
(np. Zakup, zapis do newslettera).
Wskaźniki:
 Conversion Rate (CVR): Współczynnik konwersji (Konwersje / Kliknięcia).
 CPA (Cost Per Action/Acquisition): Koszt pozyskania jednej konwersji.
 ROAS (Return on Ad Spend): Zwrot z nakładów na reklamę (Przychód / Koszt
reklamy).
 CTC/VTC (Click-Through/View-Through Conversions): Konwersje przypisane
do kliknięcia lub samego wyświetlenia reklamy
# Research: Opracowanie pytań na obronę licencjacką – Zarządzanie

## Topic summary

Kurs przygotowuje do obrony licencjackiej z kierunku Zarządzanie (specjalność: Digital Marketing). Bazą jest plik `Lista pytań kierunkowych.pdf` przekazany przez studentkę – zawiera on 30 pytań ogólnych z zarządzania (Pyt. 1–30) oraz 15 pytań specjalności Digital Marketing. Każde pytanie z załącznika dostaje własną lekcję wg sztywnego schematu: **modelowa odpowiedź egzaminacyjna → rozszerzona teoria z autorami → 3–4 quizy/widgety ABCD**. Treść lekcji jest osadzona w klasycznej polskiej i światowej literaturze zarządzania (Griffin, Stoner, Drucker, Porter, Kotler, Armstrong, Maslow, Herzberg, McGregor, Vroom, Adams, Lewin, Katz, Ansoff) oraz – w części Digital Marketing – w aktualnych standardach branżowych (IAB, Google Ads, Meta Business, GIODO/UODO).

Kurs ma charakter „comprehensive” (55 lekcji, ~15h+ pracy). Studentka zadeklarowała, że szczegóły harmonogramu są nieistotne – liczy się dotarcie do każdego pytania z listy z poprawną treścią i marketingowym, „digitalowym, dla kobiet” osadzeniem przykładów (np. Glossier, Sephora, Rossmann, Douglas, Notino, Inglot, Hebe, Lancome, Reserved, House, Mohito, Allegro Smart, Empik, Showroom). Odpowiedzi w załączniku traktujemy jako bazę do sprawdzenia poprawności – jeżeli student popełnił błąd lub uproszczenie, nie naprawiamy go w jego notatkach, ale w lekcji prezentujemy poprawnie. Każda lekcja zawiera również **gotową, 2–3-minutową wypowiedź ustną** do wyrecytowania na obronie (sekcja `theory` typu „Wypowiedź ustna”).

Quizy są typu **single-select ABCD** (z wyjątkiem rzadkich przypadków, gdzie pytanie naturalnie wymaga multi-select). Każda lekcja ma 3–4 sekcje aktywne (quiz/dragMatch/dataTable) plus warstwę teorii – łącznie 8–14 sekcji na lekcję, zgodnie z US-112. Dla pytań pamięciowych (klasyfikacje, wymienianki) stosujemy `dragMatch` lub `dataTable`; dla pytań wymagających rozumowania – `quiz` z dystraktorami zbudowanymi na typowych błędach.

Struktura kursu odwzorowuje porządek pytań w załączniku: Pyt. 1–10 (fundamenty, otoczenie, strategia), 11–16 (marketing operacyjny, cena, produkt, komunikacja), 17–20 (rachunkowość, biznesplan, strategia firmy), 21–25 (projekty, ZZL, struktury, style), 26–30 (gospodarka rynkowa, Plan Balcerowicza, podatki, cła, inflacja), DM 1–15 (specjalność Digital Marketing). Dodano moduł wprowadzający (jak korzystać z kursu, anatomia odpowiedzi, słownik, klasycy) oraz „Sekcję dodatkową” z syntezą, mapą zależności, symulacją obrony, fiszkami i checklistą na dzień obrony.

## Prerequisites

- Ukończony tok studiów licencjackich na kierunku Zarządzanie (specjalność Digital Marketing) – student zna pojęcia z zajęć i potrzebuje zwięzłego, dobrze zorganizowanego powtórzenia.
- Podstawowa znajomość terminologii biznesowej (przedsiębiorstwo, klient, produkt, koszt, zysk).
- Umiejętność czytania prostych modeli i macierzy (SWOT, BCG, Ansoff, Porter).
- Brak wymaganej znajomości matematyki finansowej, programowania ani statystyki – kurs jest opisowy.
- Założony język nauczania: **polski**. Wszystkie lekcje, quizy, wypowiedzi ustne i widgety są w języku polskim. Anglojęzyczne pojęcia branżowe (DSP, SSP, SEO, KPI, ROAS, BOPIS) podajemy w oryginale wraz z polskim wyjaśnieniem.

## Key concepts

- **Zarządzanie**: zestaw działań (planowanie, organizowanie, przewodzenie, kontrolowanie) skierowanych na zasoby organizacji w celu osiągnięcia celów sprawnie i skutecznie (Griffin, Stoner).
- **Sprawność vs skuteczność**: skuteczność = robienie właściwych rzeczy (osiąganie celu); sprawność = robienie ich we właściwy sposób (oszczędne wykorzystanie zasobów).
- **Kompetencje menedżerskie (Katz)**: techniczne, społeczne, koncepcyjne; ich proporcje zmieniają się wraz ze szczeblem zarządzania.
- **Przedsiębiorczość**: ujęcie przedmiotowe (proces tworzenia firmy, podejmowanie ryzyka) i podmiotowe (cecha zachowania – wg Druckera „przesuwanie zasobów do obszarów wyższej wydajności”).
- **Konkurencyjność vs przewaga konkurencyjna**: konkurencyjność to potencjał, przewaga – obserwowalna wyższość. Trzy strategie wg Portera: lider kosztowy, dyferencjacja, koncentracja.
- **Etyka biznesu**: kodeksy etyczne, sygnaliści (whistleblowing), szkolenia, sankcje. Naruszenia: korupcja, dyskryminacja, mobbing, oszustwa, nieuczciwa konkurencja, nieprzestrzeganie BHP.
- **Systemy informatyczne**: ERP (SAP, Microsoft Dynamics 365), CRM (Salesforce, HubSpot), SCM, BI (Power BI, Tableau), HRM, narzędzia projektowe (Asana, Trello), komunikacyjne (Teams, Zoom).
- **Otoczenie firmy**: makrootoczenie (PEST: polityczno-prawne, ekonomiczne, społeczno-kulturowe, technologiczne) i mikrootoczenie (klienci, konkurenci, dostawcy, pośrednicy).
- **Czynniki zachowań konsumentów (Kotler)**: kulturowe, społeczne, osobiste, psychologiczne (motywacja, percepcja, uczenie się, postawy).
- **SWOT/TOWS**: Strengths/Weaknesses (wewnętrzne) vs Opportunities/Threats (zewnętrzne); cztery strategie: agresywna (maxi-maxi), konserwatywna (maxi-mini), konkurencyjna (mini-maxi), defensywna (mini-mini).
- **Marketing tradycyjny vs współczesny (Kotler)**: orientacja na produkt vs na klienta; jednostronny komunikat vs dialog; transakcja vs relacja; masowość vs personalizacja.
- **Metody/techniki organizatorskie**: metody sieciowe, analiza wartości, wartościowanie pracy; matryca Eisenhowera, Pomodoro, ABC, time blocking.
- **Plan marketingowy**: streszczenie menedżerskie, analiza sytuacji (SWOT), cele SMART, strategia STP, marketing-mix (4P/5P), budżet, KPI, harmonogram.
- **Strategie cenowe**: cen niskich, neutralnych, wysokich, skimming (zbierania śmietanki), penetracji, eliminacji konkurentów. Determinanty: koszty, popyt, konkurencja, cele firmy, regulacje.
- **Cykl życia produktu**: wprowadzenie, wzrost, dojrzałość, spadek – z dopasowanymi działaniami marketingowymi.
- **IMC (Zintegrowana komunikacja marketingowa)**: reklama, PR, promocja sprzedaży, marketing bezpośredni, sprzedaż osobista; uzupełnienie digital: content marketing, social media, influencer marketing.
- **Klasyfikacja kosztów**: wg zmienności (stałe/zmienne), sposobu przypisania (bezpośrednie/pośrednie), funkcji (wytworzenia/sprzedaży/zarządu), rodzaju (układ rodzajowy: amortyzacja, materiały, usługi, podatki, wynagrodzenia, ZUS).
- **Biznesplan**: streszczenie, charakterystyka firmy, opis produktu, otoczenie wewnętrzne i zewnętrzne, marketing 4P, plany i harmonogram, analiza finansowa, załączniki. Funkcje: planistyczna, informacyjno-komunikacyjna, decyzyjna.
- **Wizja, misja, strategia**: wizja = obraz przyszłości, misja = sens istnienia, strategia = plan działania (Porter).
- **Rodzaje strategii**: korporacyjne (wzrostu/stabilizacji/defensywne), konkurencji (Porter: lider kosztowy/dyferencjacja/koncentracja), funkcjonalne, kierunki rozwoju (macierz Ansoffa: penetracja/rozwój rynku/rozwój produktu/dywersyfikacja).
- **Zarządzanie projektami**: trójkąt ograniczeń (zakres-czas-koszt); metodyki Waterfall, Agile, Scrum (sprinty, role: Product Owner, Scrum Master, Zespół; ceremonie: planning, daily, review, retrospektywa).
- **ZZL (cykl życia pracownika)**: planowanie, rekrutacja/selekcja, onboarding, ocena, rozwój, motywowanie, utrzymanie. Narzędzia: ATS, model kompetencyjny, wywiad STAR, coaching/mentoring, grywalizacja.
- **Teorie motywowania**: hierarchia potrzeb Maslowa, dwuczynnikowa Herzberga (higieny vs motywatory), oczekiwań Vrooma, sprawiedliwości Adamsa, X/Y McGregora.
- **Struktury organizacyjne**: klasyczne (liniowa, funkcjonalna, liniowo-sztabowa, dywizjonalna) i nowoczesne (macierzowa, procesowa, sieciowa).
- **Style kierowania (Lewin)**: autokratyczny, demokratyczny, liberalny (laissez-faire).
- **Gospodarka rynkowa**: dominacja własności prywatnej, wolność konkurencji, samoregulacja popyt-podaż, swobodny obrót, ograniczona ingerencja państwa.
- **Plan Balcerowicza**: stabilizacja makro, uwolnienie cen, wymienialność złotego, prywatyzacja, likwidacja monopolu w handlu zagranicznym.
- **Polityka fiskalna i monetarna**: podatki (CIT, PIT, VAT), dotacje (UE, urzędy pracy), kredyty rządowe (BGK), cła ochronne, ceny minimalne i maksymalne, inflacja.
- **POEM**: Paid (Google Ads, Meta Ads), Owned (strona, blog, newsletter, profile SM), Earned (recenzje, udostępnienia, publikacje redakcyjne).
- **Multichannel/Cross/Omnichannel**: niezależne kanały vs skoordynowane vs w pełni zintegrowane (BOPIS, BORIS, real-time inventory, unified customer profile).
- **Strategia mediowa**: 7 etapów (audyt, grupa docelowa, cele/KPI, mix kanałów, budżet/harmonogram, kreacja, optymalizacja).
- **Rodzaje kampanii**: świadomościowa/wizerunkowa, edukacyjna, sprzedażowa/performance, zaangażowania, produktowa, launchowa, promocyjna.
- **Programmatic/RTB**: DSP (kupujący), SSP (wydawca), Ad Exchange (giełda), DMP (dane); aukcja drugiej i pierwszej ceny.
- **Kreacja display**: awareness (branding, lifestyle, miękkie CTA) vs performance (produkt + cena + pilność + mocne CTA + retargeting).
- **SEO on-site**: treść (słowa kluczowe, unikalność), struktura HTML (title, meta, H1-H3), techniczna (PageSpeed, mobile-first, SSL), architektura (URL, linkowanie wewnętrzne), grafiki (ALT, kompresja).
- **Google Ads / dobór słów kluczowych**: short-tail vs long-tail, brand vs konkurencja, dopasowania (broad/phrase/exact), wykluczające, narzędzia (Keyword Planner, Trends, Senuto, Semstorm, Ahrefs).
- **Prawo autorskie**: osobiste (niezbywalne, bezterminowe) vs majątkowe (zbywalne, 70 lat po śmierci, dziedziczne).
- **Content marketing**: typy treści (tekst, wideo, audio, obraz, interaktywne, UGC) i kanały (owned, earned, paid).
- **Platformy SM**: Facebook (35-55+, lokalność), Instagram (18-34, lifestyle, Reels, Shopping), TikTok (Gen Z, In-Feed, TopView, Hashtag Challenge, TikTok Shop).
- **E-mail marketing – metryki**: dostarczalność, open rate, CTR, konwersja, unsubscribe, spam complaints; testy A/B, mapy kliknięć, segmentacja.
- **Budowa bazy e-mail**: lead magnet, double opt-in, welcome mail, RODO, bez kupowania baz.
- **Heurystyki Nielsena**: 10 zasad użyteczności (visibility of system status, match between system and real world, user control, consistency, error prevention, recognition rather than recall, flexibility, aesthetic and minimalist design, help users recognize errors, help and documentation).
- **Mechanizm emisji reklam**: Ad Request → Aukcja (DSP/SSP/AdEx) → Emisja → Interakcja → Konwersja; KPI per etap (Bid Rate, Win Rate, Impression, Viewability, CTR, VTR, CVR, CPA, ROAS).

## Common misconceptions

- „Funkcje zarządzania działają jednorazowo, sekwencyjnie” → w rzeczywistości przenikają się i tworzą ciągły proces zarządczy (cykl Deminga PDCA jest iteracyjny).
- „Sprawność i skuteczność to synonimy” → sprawność = oszczędność, skuteczność = osiąganie celu; firma może być skuteczna, ale nieefektywna i odwrotnie.
- „Globalizacja = ujednolicenie” → globalizacja zarówno standaryzuje (korzyści skali), jak i wywołuje reakcje obronne (etnocentryzm konsumencki, „polskie rzemiosło”).
- „Konkurencyjność = przewaga konkurencyjna” → konkurencyjność to potencjał, przewaga – konkretna, obserwowalna wyższość, którą widzi klient.
- „Etyka to tylko zgodność z prawem” → etyka biznesu jest wyższym standardem niż prawo; nieetyczne, choć legalne, działania (np. mobbing trudny do udowodnienia) i tak niszczą reputację.
- „SWOT i TOWS to to samo” → SWOT idzie od wnętrza na zewnątrz (jak siły wykorzystują szanse), TOWS od zewnątrz do wnętrza (jak zagrożenia uderzają w słabości) – druga macierz jest bardziej obronna.
- „Marketing współczesny = digital” → marketing współczesny to przede wszystkim orientacja na klienta i budowanie relacji; digital jest narzędziem, nie esencją.
- „Cele SMART zawsze muszą być ambitne” → A w SMART to „Achievable/Realne”, nie „Ambitne” – ambicja jest pożądana, ale nie kosztem realizmu (różne podręczniki podają różne rozwinięcia A; podajemy oba).
- „Strategia penetracji = strategia cen niskich” → penetracja to konkretnie wprowadzenie produktu po niskiej cenie, by szybko zdobyć udział; strategia niskich cen może dotyczyć dowolnej fazy.
- „Skimming jest dla każdego nowego produktu” → skimming wymaga innowacyjności, ograniczonej konkurencji i krótkiego cyklu życia – nie zadziała przy szybko kopiowanych produktach.
- „Cykl życia produktu jest deterministyczny” → fazy mogą się kurczyć/wydłużać, a aktywne zarządzanie (rejuvenation) wydłuża dojrzałość.
- „Koszty stałe są niezmienne” → niezmienne wobec wielkości produkcji, ale mogą rosnąć/spadać (czynsz, podwyżki); ważne jest, że nie zależą od skali.
- „Biznesplan = prognoza finansowa” → to znacznie więcej: opisuje koncepcję, otoczenie, strategię, ZZL, marketing; analiza finansowa jest kluczową, ale nie jedyną częścią.
- „Misja = wizja, tylko inaczej” → misja odpowiada na pytanie „kim jesteśmy teraz”, wizja – „kim chcemy być w przyszłości”.
- „Macierz Ansoffa = strategie Portera” → Ansoff dotyczy kierunków rozwoju (produkt × rynek), Porter – sposobu konkurowania w branży.
- „Agile = brak planowania” → Agile zakłada planowanie iteracyjne (per sprint), nie brak planu; to filozofia, nie metoda.
- „Scrum = Agile” → Scrum to jedna z metodyk Agile, obok Kanban, XP, SAFe.
- „Maslow obowiązuje sztywno” → współczesna psychologia kwestionuje sztywność hierarchii; w praktyce ludzie zaspokajają potrzeby równolegle.
- „Higieny Herzberga = motywatory” → higieny zapobiegają niezadowoleniu, ale nie motywują trwale; tylko motywatory budują rzeczywiste zaangażowanie.
- „Teoria X jest zła, Y dobra” → McGregor pokazał, że styl zarządzania zależy od założeń lidera; oba mogą być sytuacyjnie uzasadnione.
- „Struktura macierzowa = chaos” → wprowadza podwójne podporządkowanie, ale w zamian daje wysoką elastyczność i koordynację – kluczem są jasne reguły eskalacji.
- „Styl liberalny = brak zarządzania” → styl liberalny działa świetnie w zespołach ekspertów, gdzie kontrola hamowałaby kreatywność; źle stosowany prowadzi do chaosu.
- „Plan Balcerowicza nie miał kosztów społecznych” → bezrobocie, spadek realnych dochodów, rozwarstwienie były ceną stabilizacji – warto to znać, by odpowiadać uczciwie.
- „VAT to koszt firmy” → VAT firma odprowadza, ale finalnie płaci go konsument; problem dla firmy to płynność (zatory płatnicze).
- „Cło chroni gospodarkę bez kosztów” → cło prowadzi do wyższych cen, mniejszego wyboru i ryzyka „wojny celnej”.
- „Inflacja zawsze szkodzi wszystkim” → faworyzuje dłużników (realna wartość długu spada) kosztem wierzycieli i oszczędzających – to redystrybucja, nie tylko strata.
- „POEM to to samo co kanały marketingowe” → POEM to model klasyfikacji *własności* mediów; kanał (np. blog) może występować w więcej niż jednej kategorii.
- „Omnichannel = wielokanałowość” → multichannel = wiele równoległych kanałów, omnichannel = pełna integracja danych i spójne doświadczenie.
- „RTB = jedna technologia” → RTB to model aukcji (real-time), a programmatic obejmuje także PMP (private marketplaces), programmatic guaranteed itp.
- „SEO on-site = optymalizacja techniczna” → on-site obejmuje treść, strukturę HTML, technikę, architekturę, grafiki; off-site (linki zewnętrzne) to osobny obszar.
- „Broad match Google Ads to najlepszy wybór” → broad match daje zasięg, ale przepala budżet; bez negatywów i mocnych konwersji szybko traci sens.
- „Prawa autorskie wygasają od dnia stworzenia” → majątkowe wygasają 70 lat *po śmierci autora*, nie od stworzenia.
- „Heurystyki Nielsena dotyczą tylko UI” → dotyczą każdego interfejsu (web, mobile, voice, kioski), a wiele zasad (consistency, error prevention) jest też dobrą praktyką w komunikacji marketingowej.

## Suggested ordering

1. **Wprowadzenie i fundamenty** (4 lekcje): jak korzystać z kursu, anatomia odpowiedzi, glosariusz, klasycy. Dajemy studentce ramy, w których będzie pracować z 51 pytaniami.
2. **Funkcje i otoczenie zarządzania (Pyt. 1–10)** (10 lekcji): od najszerszych pojęć (funkcje, globalizacja) przez kompetencje, przedsiębiorczość, etykę, IT, otoczenie, konsumentów, do narzędzia analitycznego SWOT/TOWS – tradycyjna kolejność akademicka.
3. **Marketing operacyjny i produktowy (Pyt. 11–16)** (6 lekcji): od porównania marketingu tradycyjnego/współczesnego, przez metody/techniki, plan marketingowy, ceny, cykl życia, do narzędzi IMC.
4. **Finanse, biznesplan i strategia firmy (Pyt. 17–20)** (4 lekcje): rachunkowość → biznesplan → wizja/misja/strategia → klasyfikacje strategii. Naturalne przejście od kosztów do strategii.
5. **Projekty, ludzie i struktury (Pyt. 21–25)** (5 lekcji): zarządzanie projektami → ZZL → motywowanie → struktury → style kierowania. Wszystkie są o organizacji wnętrza firmy.
6. **Gospodarka, polityka makro i instrumenty (Pyt. 26–30)** (5 lekcji): zasady gospodarki rynkowej → Plan Balcerowicza → podatki/dotacje/kredyty → cła i ceny administracyjne → inflacja. Tematy często zadawane jako pytania pogłębiające.
7. **Digital Marketing: media, kanały i kampanie (Pyt. DM 1–7)** (7 lekcji): POEM → omnichannel → strategia mediowa → kampanie → programmatic → kreacja display → SEO on-site. Od strategii do operacji.
8. **Digital Marketing: SEM, prawo, treść, social, e-mail i UX (Pyt. DM 8–15)** (8 lekcji): Google Ads → prawo autorskie → content → social media → analityka maila → budowa bazy → Nielsen → mechanizm emisji. Dopełnienie specjalności.
9. **Sekcja dodatkowa – uzupełnienia i powtórka** (6 lekcji): mini-słownik, mapa zależności, symulacja obrony, pytania pogłębiające komisji, fiszki, checklist – ostatni tydzień przed obroną.

## Notes for lesson generation

- **Język**: wszystkie sekcje, quizy, wypowiedzi ustne i etykiety widgetów po polsku. Anglojęzyczne terminy branżowe podajemy z polskim tłumaczeniem przy pierwszym wystąpieniu.
- **Sztywny szkielet lekcji „pytaniowej”** (Pyt. 1–30, DM 1–15): każda lekcja ma 3 warstwy + zamknięcie:
  1. **Modelowa odpowiedź egzaminacyjna** (sekcja `theory`, ~250–400 słów) – treściwa odpowiedź jaką student wygłosi przed komisją, ujęta w strukturę: definicja → klasyfikacja → przykład → nazwiska autorów → podsumowanie. Sekcja musi być w pełni samodzielna – student powinien móc ją wyrecytować.
  2. **Wypowiedź ustna 2–3 min** (sekcja `theory` zatytułowana „Wypowiedź ustna na obronę”) – wersja mówiona modelowej odpowiedzi (650–900 znaków, ~2–3 min czytania), z naturalnymi przejściami („W literaturze zarządzania…”, „Klasycznym przykładem jest…”, „Podsumowując…”).
  3. **Rozszerzona teoria z autorami** (1–2 sekcje `theory`, ~500–800 słów) – pełniejsze tło: cytowani autorzy (Drucker, Porter, Kotler, Griffin, Stoner, Armstrong), kontekst historyczny, dodatkowe klasyfikacje, niuanse, których nie ma w odpowiedzi „minimum”.
  4. **3–4 widgety/quizy interaktywne** w jednej z form:
     - `quiz` (single-select ABCD) – domyślny wybór; dystraktory budujemy z misconceptions z tej listy.
     - `dragMatch` – do dopasowywania (np. termin → definicja, autor → teoria, kompetencja → szczebel).
     - `dataTable` – do klasyfikacji wielokolumnowych (np. strategie cenowe × determinanty × przykłady, koszty × kategoria × przykład).
     - **Bardzo rzadko** `quiz` multi-select („wskaż wszystkie cechy stylu autokratycznego”).
- **Liczba sekcji**: 8–14 (US-112). Typowy układ: theory (modelowa odpowiedź) → theory (wypowiedź ustna) → theory (teoria rozszerzona część 1) → quiz/dragMatch → theory (teoria rozszerzona część 2) → quiz → dragMatch lub dataTable → quiz końcowy → opcjonalnie krótkie theory podsumowujące.
- **Przykłady marketingowe – digital, dla kobiet**: Glossier, Sephora, Rossmann, Hebe, Douglas, Notino, Inglot, MAC, Lancome, Chanel, Reserved, Mohito, House, Showroom, Allegro, Empik, Booking, Airbnb, Spotify, Netflix, Starbucks, Empik Premium, Pyszne.pl, Allegro Smart!, Klarna, BLIK. W lekcjach z teorii ogólnej (np. funkcje zarządzania) używamy też ogólnych marek (IKEA, Ryanair, Nike, Apple), ale gdy pytanie dotyczy marketingu/cyfrowego – preferujemy marki kosmetyczne/modowe/foodtech znane studentkom.
- **Autorzy do wplatania**: w lekcjach z zarządzania ogólnego cytujemy zawsze min. 1 nazwisko klasyka (Griffin, Stoner, Drucker, Porter, Kotler, Armstrong); w lekcjach motywowania – Maslow, Herzberg, Vroom, Adams, McGregor; w stylach kierowania – Lewin; w kompetencjach – Katz; w strategiach rozwoju – Ansoff. Studentka deklaruje preferencję pełniejszego tła, więc nazwiska są ważniejsze niż minimalizm.
- **Quiz – konstrukcja dystraktorów**: zawsze min. 1 dystraktor pochodzi z `Common misconceptions`; pozostałe są wiarygodne ale niepoprawne (np. zamiana etapu, autora, definicji). Wyjaśnienie po quizie cytuje konkretnego autora lub konkretną cechę zjawiska, nie parafrazuje pytania.
- **Brak treści kodowych / matematycznych**: kurs nie używa widgetów `code`, `codeCloze`, `parametricExplorer`, `histogram`, `plotImage`, `demo`, `sandbox` – nie ma sensownego zastosowania pythona ani statycznych wykresów w treści zarządczej. KaTeX można pojedynczo użyć dla wzorów typu `$\text{ROAS} = \frac{\text{Przychód z reklam}}{\text{Koszt reklam}}$` w lekcjach analityki marketingowej (DM 12, DM 15).
- **Tabele referencyjne**: pytania klasyfikacyjne (np. Pyt. 14 – strategie cenowe, Pyt. 23 – teorie motywowania, Pyt. 24 – struktury organizacyjne, Pyt. DM 11 – platformy SM) mają **dataTable** z kolumnami: nazwa, charakterystyka, determinanty/zalety, przykład.
- **Ćwiczenia matchujące**: Pyt. 1 (funkcja → przykład działania), Pyt. 5 (przewaga → marka-przykład: Apple/Ryanair/Lidl), Pyt. 7 (system IT → konkretne narzędzie), Pyt. 8 (czynnik PEST → przykład), Pyt. 19 (firma → misja), Pyt. 21 (Waterfall/Agile/Scrum → cecha), Pyt. 24 (struktura → przykład firmy), Pyt. DM 1 (kanał → POEM-kategoria), Pyt. DM 5 (rola → DSP/SSP/DMP/AdEx), Pyt. DM 15 (KPI → etap emisji).
- **Sekcja dodatkowa (Moduł 9)** – lekcje *nie* są pytaniami z listy:
  - „Mini-słownik dodatkowych pojęć z literatury” – widget `dataTable` z 30+ pojęciami (ROI, CAC, LTV, KPI, OKR, PEST, BCG, Six Sigma, Kaizen, Lean, MBO, Stakeholder, Outsourcing, Insourcing, Benchmarking, Mentoring, Coaching, Onboarding, Offboarding, Whistleblowing, Lead, MQL, SQL, Funnel, Touchpoint, NPS, CES, Churn, Retention, AOV, Bounce Rate, Engagement Rate, Reach, Frequency).
  - „Mapa zależności tematycznych pytań” – widget `dragMatch` lub `dataTable`: pyt. 1 ↔ pyt. 25 (przewodzenie i style), pyt. 10 ↔ pyt. 13 (SWOT w planie marketingowym), pyt. 18 ↔ pyt. 19 ↔ pyt. 20 (biznesplan, misja, strategia), pyt. 14 ↔ pyt. 15 (cena × cykl życia), pyt. DM 1 ↔ pyt. DM 3 ↔ pyt. DM 4 (POEM × strategia × kampanie).
  - „Symulacja obrony” – 5 quizów z losowymi pytaniami z listy + sekcja `theory` z mini-rolą egzaminatora („Komisja pyta: …”). Dystraktory mocne, aby trenować pewność.
  - „Najczęstsze pytania dodatkowe komisji” – `dataTable` z 30+ pytaniami pogłębiającymi (np. „Czym różni się sprawność od skuteczności?”, „Dlaczego planowanie jest najważniejszą funkcją?”, „Co to outsourcing?”, „Czym różni się SWOT od TOWS?”, „Dlaczego skimming nie zadziała na rynku konkurencyjnym?”) z wzorcowymi krótkimi odpowiedziami.
  - „Powtórka błyskawiczna – fiszki z 45 pytań” – `dragMatch` z 45 pytaniami i 45 jednolinijkowymi odpowiedziami; uzupełniona o quiz „przyporządkuj odpowiedź do pytania”.
  - „Checklist na dzień obrony” – widget `dataTable` z kategoriami: dokumenty, strój, mowa ciała, kluczowe nazwiska/cytaty, przygotowanie psychiczne; plus krótkie theory z 5 ostatnimi „złotymi zasadami”.
- **Brak wątków matematyczno-finansowych w lekcjach kosztów (Pyt. 17) i biznesplanu (Pyt. 18)**: studentka nie deklaruje znajomości rachunkowości w głębi – treść jest opisowa, klasyfikacyjna, bez liczenia bilansów ani BEP. Pojęcia są wyjaśnione, formuły – wymienione (próg rentowności, DSC, ROI), ale nie liczymy.
- **Część gospodarki makro (Pyt. 26–30)**: wątki wykraczają poza marketing, ale są częścią pytań kierunkowych. Treść utrzymujemy na poziomie podręcznikowym (Begg, Samuelson, Hall) z polskimi przykładami (NBP, Plan Balcerowicza, BGK, dotacje UE, Tarcza Antykryzysowa). Bez oceny politycznej.
- **Część Digital Marketing (Pyt. DM 1–15)**: tu cytujemy aktualne źródła branżowe (IAB Polska, Google Ads Help, Meta Business, Mailchimp/GetResponse blogs *unikamy* – preferujemy oficjalne docs).
- **Wątek RODO/UODO** (Pyt. DM 9, DM 13): wymienić wymóg zgody (consent), prawo do bycia zapomnianym, double opt-in jako standard – ale bez wchodzenia w paragrafy.
- **Korekta błędów w notatkach studentki**: zachowujemy zasadę „nie naprawiaj, ale pisz poprawnie” – w lekcji nie odwołujemy się do notatek („Twoje notatki mówią X, ale właściwie…”). Po prostu prezentujemy poprawną definicję. Wyjątek: pyt. 15 (cykl życia) – w notatkach jest literówka „funkcjotnalności”; w lekcji piszemy poprawnie „funkcjonalności” bez komentarza.
- **Stosunek teoria/praktyka 0.5**: równowaga między teorią a quizami/widgetami. Każda lekcja pytaniowa ma ~50% sekcji `theory` i ~50% `quiz/dragMatch/dataTable`. Lekcje wprowadzające (Moduł 1) i syntetyzujące (Moduł 9) mogą mieć więcej widgetów (do 60%).
